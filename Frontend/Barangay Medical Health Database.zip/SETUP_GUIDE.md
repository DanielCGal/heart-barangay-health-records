# HEART — Setup & Backend Connection Guide
## Gov. Paciano Bangoy Barangay Health Center

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Prerequisites](#2-prerequisites)
3. [Frontend Setup (Run Locally)](#3-frontend-setup-run-locally)
4. [Environment Variables](#4-environment-variables)
5. [Understanding Mock Mode vs Real API](#5-understanding-mock-mode-vs-real-api)
6. [Default Test Credentials](#6-default-test-credentials)
7. [Backend Requirements — All API Endpoints](#7-backend-requirements--all-api-endpoints)
8. [Database Schema](#8-database-schema)
9. [Switching from Mock to Real API](#9-switching-from-mock-to-real-api)
10. [CORS Configuration](#10-cors-configuration)
11. [Authentication Flow](#11-authentication-flow)
12. [Logbook Auto-Tracking (Important)](#12-logbook-auto-tracking-important)
13. [File Structure Reference](#13-file-structure-reference)
14. [Deployment Checklist](#14-deployment-checklist)

---

## 1. Project Overview

**HEART** is a React + TypeScript + Vite single-page application (SPA).

| Layer | Technology |
|---|---|
| Frontend framework | React 18 + TypeScript |
| Build tool | Vite 6 |
| Styling | Tailwind CSS v4 |
| Routing | react-router v7 |
| Animation | motion/react (Motion) |
| HTTP client | Native `fetch` (in `/src/api/config.ts`) |
| Auth storage | `localStorage` (JWT token + user object) |

The frontend is **completely decoupled** from any backend.
All API calls live in `/src/api/` and currently run in
**mock mode** (in-memory data, no network calls).

---

## 2. Prerequisites

Install these tools before doing anything else.

### Node.js
Version **18 or higher** is required.
Download from: https://nodejs.org/

Verify:
```
node -v     # should print v18.x.x or higher
```

### pnpm (Package Manager)
This project uses **pnpm**, not npm or yarn.

Install it:
```
npm install -g pnpm
```

Verify:
```
pnpm -v     # should print 8.x.x or higher
```

### Git (optional, for cloning)
Download from: https://git-scm.com/

---

## 3. Frontend Setup (Run Locally)

### Step 1 — Get the project files

If you received a ZIP file, extract it to a folder (e.g. `heart-app`).
If you are using Git:
```
git clone <your-repo-url> heart-app
cd heart-app
```

### Step 2 — Install dependencies
```
pnpm install
```

This reads `package.json` and downloads all packages into `node_modules/`.
It may take 1–2 minutes on first run.

### Step 3 — Create your environment file

Copy the example file:
```
cp .env.example .env
```

On Windows (Command Prompt):
```
copy .env.example .env
```

Leave it blank for now if you are only testing mock mode.
(See Section 4 for what to put inside once you have a backend.)

### Step 4 — Start the development server
```
pnpm run dev
```

Open your browser at: **http://localhost:5173**

You should see the HEART login page.

### Step 5 — Build for production (when ready to deploy)
```
pnpm run build
```

This creates a `dist/` folder with static files you can upload
to any web hosting service (Nginx, Apache, Vercel, Netlify, etc.).

---

## 4. Environment Variables

The only environment variable the frontend needs is:

```
# .env
VITE_API_BASE_URL=http://localhost:8000
```

| Variable | Description | Example |
|---|---|---|
| `VITE_API_BASE_URL` | Full base URL of your backend API (no trailing slash) | `http://localhost:8000` |

**Rules:**
- All Vite environment variables must start with `VITE_`
- Do NOT put secrets (passwords, private keys) in `.env` — this file
  is bundled into the browser build
- Never commit `.env` to Git — it is already in `.gitignore`
- For production, set the variable in your hosting platform's
  environment settings instead of a `.env` file

**Local vs production example:**
```
# .env  (local development)
VITE_API_BASE_URL=http://localhost:8000

# production (set in hosting dashboard)
VITE_API_BASE_URL=https://api.yourheartapp.ph
```

---

## 5. Understanding Mock Mode vs Real API

Every function in `/src/api/` has two clearly-labelled blocks:

```typescript
export async function getPatients(): Promise<Patient[]> {

  // ── MOCK MODE ────────────────────────────────────────
  await fakeDelay();
  return [..._patients];          // ← uses in-memory data
  // ── END MOCK ─────────────────────────────────────────

  // ── REAL API ─────────────────────────────────────────
  // return apiGet<Patient[]>("/patients");  // ← real fetch
  // ── END REAL ─────────────────────────────────────────
}
```

**Mock mode is active by default.**

In mock mode:
- No network requests are made
- Data lives in memory (resets every browser refresh)
- 8 sample patients are pre-loaded from `mockData.ts`
- Login works with any username + password `password123`

When you are ready to connect a real backend, you will
delete the MOCK block and uncomment the REAL API block
for each function (see Section 9).

---

## 6. Default Test Credentials

Use these to log in while running in mock mode:

| Field | Value |
|---|---|
| ID / Mobile Number | any text (e.g. `admin` or `staff123`) |
| Password | `password123` |

The mock user that gets returned:

| Property | Value |
|---|---|
| Full Name | Maria Santos |
| Email | m.santos@healthcenter.gov.ph |
| Role | Health Staff |

---

## 7. Backend Requirements — All API Endpoints

Your backend must implement these **13 REST endpoints**.
The frontend calls them relative to `VITE_API_BASE_URL`.

---

### AUTH  (`/auth`)

#### POST `/auth/login`
Log in a staff member and return a JWT token.

**Request body:**
```json
{
  "identifier": "nurse01",
  "password": "mysecretpassword"
}
```
`identifier` can be a username, staff ID, or mobile number.

**Success response (200):**
```json
{
  "token": "eyJhbGci...",
  "user": {
    "id": "staff-001",
    "fullName": "Maria Santos",
    "email": "m.santos@healthcenter.gov.ph",
    "role": "Health Staff"
  }
}
```

**Error response (401):**
```json
{ "message": "Invalid credentials." }
```

---

#### POST `/auth/logout`
Invalidate the session on the server side (optional but recommended).

**Request:** empty body `{}`
**Response:** `204 No Content`

---

#### PATCH `/auth/me/email`
Update the logged-in user's email.

**Request body:**
```json
{ "email": "new.email@healthcenter.gov.ph" }
```
**Response (200):** Updated `AuthUser` object (same shape as login user)

---

#### PATCH `/auth/me/password`
Change the logged-in user's password.

**Request body:**
```json
{
  "currentPassword": "oldpassword",
  "newPassword": "newpassword123"
}
```
**Response:** `200 OK` or `400 Bad Request` if current password is wrong.

---

### PATIENTS  (`/patients`)

#### GET `/patients`
Returns all (non-archived) patient records.

**Response (200):**
```json
[ { ...Patient }, { ...Patient } ]
```

---

#### GET `/patients/:id`
Returns a single patient by ID.

**Response (200):** `{ ...Patient }`
**Response (404):** `{ "message": "Patient not found." }`

---

#### POST `/patients`
Creates a new patient record.

**Request body:** Patient object without `id`
**Response (201):** Created Patient object with `id`

---

#### PUT `/patients/:id`
Replaces a patient record (full update).

**Request body:** Full Patient object (including `id`)
**Response (200):** Updated Patient object

---

#### DELETE `/patients/:id`
Hard-deletes a patient record.

**Response:** `204 No Content`

---

### LOGBOOK  (`/logbook`)

#### GET `/logbook`
Returns all logbook entries (most recent first recommended).

**Response (200):**
```json
[
  {
    "id": 1,
    "username": "nurse01",
    "action": "Edit Record",
    "patientName": "Juniel del Rosario",
    "timestamp": "February 14, 2026, 10:30 AM"
  }
]
```

---

#### POST `/logbook`
Creates a new audit log entry.

**Request body:**
```json
{
  "staffUsername": "nurse01",
  "action": "Edit Record",
  "patientName": "Juniel del Rosario",
  "patientId": 1
}
```

Valid `action` values:
- `"Add Record"` — patient was registered
- `"Edit Record"` — patient was updated
- `"Delete Record"` — patient was hard-deleted
- `"Archive"` — patient was archived
- `"Restore"` — patient was restored from archive

The backend should auto-set the `timestamp`.

**Response (201):** Created LogbookEntry object with `id` and `timestamp`

---

#### PUT `/logbook/:id`
Updates an existing logbook entry (e.g. to correct a mistake).

**Request body:** Full LogbookEntry object
**Response (200):** Updated LogbookEntry

---

### ARCHIVE  (`/archive`)

#### GET `/archive`
Returns all archived patient records.

**Response (200):**
```json
[
  {
    "id": 1,
    "lastName": "del Rosario",
    "firstName": "Juniel",
    "middleInitial": "B",
    "startDatetime": "January 28, 2026, 09:00 AM",
    "endDatetime": "March 1, 2026, 03:00 PM"
  }
]
```

---

#### POST `/archive`
Archives a patient (moves them to the archive table).

**Request body:**
```json
{
  "patientId": 3,
  "lastName": "Ali",
  "firstName": "Abdujideen",
  "middleInitial": "M",
  "startDatetime": "January 28, 2026, 10:00 AM"
}
```
The backend should auto-set `endDatetime` to the current time.

**Response (201):** Created ArchiveEntry object

---

#### DELETE `/archive/:id`
Restores a patient from the archive (removes the archive entry).

**Response:** `204 No Content`

---

### STAFF  (`/staff`)

#### GET `/staff`
Returns a list of staff usernames (used in logbook dropdowns).

**Response (200):**
```json
["staff123", "admin01", "nurse01", "midwife01"]
```

---

## 8. Database Schema

Recommended relational database (PostgreSQL or MySQL).
See `/DATABASE_FIELDS.txt` for the complete field list.

Here is the SQL skeleton to create the tables:

```sql
-- ── TABLE 1: patients ──────────────────────────────────────────────
CREATE TABLE patients (
  id                      SERIAL PRIMARY KEY,
  last_name               VARCHAR(100)  NOT NULL,
  first_name              VARCHAR(100)  NOT NULL,
  middle_initial          VARCHAR(5),
  age                     INTEGER,
  age_months              INTEGER DEFAULT 0,
  sex                     VARCHAR(10)   NOT NULL,  -- 'Male' | 'Female'
  birthday                DATE,                    -- YYYY-MM-DD
  religion                VARCHAR(100),
  civil_status            VARCHAR(20),
  contact_number          VARCHAR(11),             -- digits only, 11 chars
  educational_attainment  VARCHAR(100),
  occupation              VARCHAR(100),
  spouse_name             VARCHAR(200),
  spouse_occupation       VARCHAR(100),
  spouse_contact          VARCHAR(11),             -- digits only, 11 chars
  address                 TEXT,
  purok                   VARCHAR(100),
  barangay                VARCHAR(100),
  city                    VARCHAR(100),
  program                 VARCHAR(100),
  family_planning         BOOLEAN DEFAULT FALSE,
  vitamins                BOOLEAN DEFAULT FALSE,
  children                INTEGER DEFAULT 0,
  co_morbidities          TEXT,                   -- comma-joined or "None"
  cancer                  VARCHAR(200),            -- "None" | free-text
  allergies               TEXT,                    -- "None" | free-text
  maintenance_medication  TEXT,
  previous_illnesses      TEXT,
  last_visit              DATE,                    -- YYYY-MM-DD
  blood_pressure          VARCHAR(30),             -- "120/80 mmHg"
  weight                  VARCHAR(20),             -- "58 kg"
  height                  VARCHAR(20),             -- "155 cm"
  bcg_vaccine             VARCHAR(5),              -- 'YES'|'NO'|'N/A'
  hep_b_vaccine           VARCHAR(5),
  vitamin_k               VARCHAR(5),
  family_history_conditions TEXT,                  -- JSON array
  family_history_other    TEXT,
  family_history_mother   VARCHAR(5),
  is_archived             BOOLEAN DEFAULT FALSE,
  archived_at             TIMESTAMP,
  created_at              TIMESTAMP DEFAULT NOW(),
  updated_at              TIMESTAMP DEFAULT NOW()
);

-- ── TABLE 2: personal_social_history ──────────────────────────────
CREATE TABLE personal_social_history (
  id                          SERIAL PRIMARY KEY,
  patient_id                  INTEGER REFERENCES patients(id) ON DELETE CASCADE,
  eats_healthy_diet           BOOLEAN DEFAULT FALSE,
  adequate_physical_activity  BOOLEAN DEFAULT FALSE,
  sufficient_rest_sleep       BOOLEAN DEFAULT FALSE,
  normal_growth_development   BOOLEAN DEFAULT FALSE,
  multiple_partners           BOOLEAN DEFAULT FALSE,
  smokes_tobacco              BOOLEAN DEFAULT FALSE,
  tobacco_packs_per_year      INTEGER DEFAULT 0,
  drinks_alcohol              BOOLEAN DEFAULT FALSE,
  alcohol_bottles_per_year    INTEGER DEFAULT 0,
  takes_illegal_drugs         BOOLEAN DEFAULT FALSE,
  illegal_drugs_specify       TEXT
);

-- ── TABLE 3: physical_exam ─────────────────────────────────────────
CREATE TABLE physical_exam (
  id                        SERIAL PRIMARY KEY,
  patient_id                INTEGER REFERENCES patients(id) ON DELETE CASCADE,
  exam_date                 DATE,
  sheent_normal             BOOLEAN DEFAULT TRUE,
  sheent_findings           TEXT,                 -- JSON array of strings
  sheent_others             TEXT,
  chest_normal              BOOLEAN DEFAULT TRUE,
  chest_findings            TEXT,
  chest_others              TEXT,
  heart_normal              BOOLEAN DEFAULT TRUE,
  heart_findings            TEXT,
  heart_others              TEXT,
  abdomen_normal            BOOLEAN DEFAULT TRUE,
  abdomen_findings          TEXT,
  abdomen_others            TEXT,
  genitourinary_normal      BOOLEAN DEFAULT TRUE,
  genitourinary_findings    TEXT,
  genitourinary_others      TEXT,
  extremities_normal        BOOLEAN DEFAULT TRUE,
  extremities_findings      TEXT,
  extremities_others        TEXT,
  neurological_normal       BOOLEAN DEFAULT TRUE,
  neurological_findings     TEXT,
  neurological_others       TEXT
);

-- ── TABLE 4: maternal_records ──────────────────────────────────────
CREATE TABLE maternal_records (
  id                    SERIAL PRIMARY KEY,
  patient_id            INTEGER REFERENCES patients(id) ON DELETE CASCADE,
  gravida               INTEGER DEFAULT 0,
  para                  INTEGER DEFAULT 0,
  full_term             INTEGER DEFAULT 0,
  preterm               INTEGER DEFAULT 0,
  abortion              INTEGER DEFAULT 0,
  living                INTEGER DEFAULT 0,
  menarche_age          INTEGER,
  menstrual_cycle       VARCHAR(20),             -- 'Regular' | 'Irregular'
  menstrual_flow_days   INTEGER,
  coitarche_age         INTEGER,
  current_fp_method     VARCHAR(200),
  pap_smear             BOOLEAN DEFAULT FALSE,
  pap_smear_date        DATE,
  pap_smear_result      VARCHAR(200),
  via                   BOOLEAN DEFAULT FALSE,
  via_date              DATE,
  via_result            VARCHAR(200),
  history_of_sti        BOOLEAN DEFAULT FALSE,
  sti_date              DATE,
  sti_result            VARCHAR(200),
  risk_code             VARCHAR(100),
  mother_baby_book      BOOLEAN DEFAULT FALSE,
  lmp                   DATE,
  edd                   DATE,
  plan_to_deliver_at    VARCHAR(200),
  age_of_gestation      VARCHAR(50),
  accompanying_person   VARCHAR(200),
  seen_by_dentist       BOOLEAN DEFAULT FALSE,
  dentist_date          DATE,
  dentist_visit_1       INTEGER DEFAULT 0,
  dentist_visit_2       INTEGER DEFAULT 0,
  dentist_visit_3       INTEGER DEFAULT 0,
  seen_by_physician     BOOLEAN DEFAULT FALSE,
  physician_date        DATE,
  physician_visit_1     INTEGER DEFAULT 0,
  physician_visit_2     INTEGER DEFAULT 0,
  physician_visit_3     INTEGER DEFAULT 0,
  tt1                   VARCHAR(20),             -- "March 2021" or ""
  tt2                   VARCHAR(20),
  tt3                   VARCHAR(20),
  tt4                   VARCHAR(20),
  tt5                   VARCHAR(20),
  iodized_salt          BOOLEAN DEFAULT FALSE,
  iron_supplement       BOOLEAN DEFAULT FALSE
);

-- ── TABLE 5: logbook_entries ───────────────────────────────────────
CREATE TABLE logbook_entries (
  id            SERIAL PRIMARY KEY,
  staff_username VARCHAR(100) NOT NULL,
  action        VARCHAR(50)  NOT NULL,
  patient_name  VARCHAR(200) NOT NULL,
  patient_id    INTEGER REFERENCES patients(id) ON DELETE SET NULL,
  timestamp     TIMESTAMP DEFAULT NOW()
);

-- ── TABLE 6: archive_entries ───────────────────────────────────────
CREATE TABLE archive_entries (
  id              SERIAL PRIMARY KEY,
  patient_id      INTEGER REFERENCES patients(id) ON DELETE SET NULL,
  last_name       VARCHAR(100),
  first_name      VARCHAR(100),
  middle_initial  VARCHAR(5),
  start_datetime  TIMESTAMP,
  end_datetime    TIMESTAMP DEFAULT NOW()
);

-- ── TABLE 7: staff_accounts ────────────────────────────────────────
CREATE TABLE staff_accounts (
  id              VARCHAR(50) PRIMARY KEY,
  username        VARCHAR(100) UNIQUE NOT NULL,
  full_name       VARCHAR(200) NOT NULL,
  email           VARCHAR(200) UNIQUE,
  password_hash   VARCHAR(255) NOT NULL,
  role            VARCHAR(50),
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW()
);
```

> **JSON columns tip:** For arrays like `family_history_conditions`
> and `physical_exam.sheent_findings`, store them as a JSON string
> in a TEXT column, or use a native JSON/JSONB column if your
> database supports it (PostgreSQL `jsonb` is recommended).
>
> Example: `'["Hypertension", "Diabetes"]'`

---

## 9. Switching from Mock to Real API

For each service file, the process is the same 3 steps:

1. **Delete** the `// ── MOCK MODE ──` block
2. **Uncomment** the `// ── REAL API ──` block
3. **Uncomment** the import at the top of the file

Do this for each of the 6 service files, one by one.

---

### Step-by-step: `patients.service.ts`

**Before (mock):**
```typescript
import {
  fakeDelay,
  // apiGet,
  // apiPost,
  // apiPut,
  // apiDelete,
} from "./config";

export async function getPatients(): Promise<Patient[]> {
  // ── MOCK MODE ──
  await fakeDelay();
  return [..._patients];
  // ── END MOCK ──

  // ── REAL API ──
  // return apiGet<Patient[]>("/patients");
  // ── END REAL ──
}
```

**After (real):**
```typescript
import {
  apiGet,
  apiPost,
  apiPut,
  apiDelete,
} from "./config";

// ← delete the let _patients line too

export async function getPatients(): Promise<Patient[]> {
  return apiGet<Patient[]>("/patients");
}
```

Repeat for `getPatientById`, `createPatient`, `updatePatient`,
and `deletePatient`.

---

### Step-by-step: `auth.service.ts`

**Before (mock):**
```typescript
import {
  tokenStorage, userStorage,
  // apiPost,
  // apiPatch,
  fakeDelay,
} from "./config";

// Delete these two lines ↓
const MOCK_PASSWORD = "password123";
const MOCK_USER: AuthUser = { ... };
```

**After (real):**
```typescript
import {
  tokenStorage, userStorage,
  apiPost,
  apiPatch,
} from "./config";

// login
export async function login(identifier: string, password: string): Promise<AuthUser> {
  const res = await apiPost<{ token: string; user: AuthUser }>("/auth/login", {
    identifier,
    password,
  });
  tokenStorage.set(res.token);
  userStorage.set(res.user);
  return res.user;
}

// logout
export async function logout(): Promise<void> {
  await apiPost("/auth/logout", {});
  tokenStorage.clear();
}

// updateEmail
export async function updateEmail(newEmail: string): Promise<AuthUser> {
  const updated = await apiPatch<AuthUser>("/auth/me/email", { email: newEmail });
  userStorage.set(updated);
  return updated;
}

// updatePassword
export async function updatePassword(currentPassword: string, newPassword: string): Promise<void> {
  await apiPatch("/auth/me/password", { currentPassword, newPassword });
}
```

---

### Step-by-step: `logbook.service.ts`

**After (real):**
```typescript
import { apiGet, apiPost, apiPut } from "./config";

export async function getLogbook(): Promise<LogbookEntry[]> {
  return apiGet<LogbookEntry[]>("/logbook");
}

export async function addLogbookEntry(entry: NewLogbookEntry): Promise<LogbookEntry> {
  return apiPost<LogbookEntry>("/logbook", {
    staffUsername : entry.staffUsername,
    action        : entry.action,
    patientName   : entry.patientName,
    patientId     : entry.patientId,
  });
}

export async function updateLogbookEntry(id: number, data: LogbookEntry): Promise<LogbookEntry> {
  return apiPut<LogbookEntry>(`/logbook/${id}`, data);
}
```

---

### Step-by-step: `archive.service.ts`

**After (real):**
```typescript
import { apiGet, apiPost, apiDelete } from "./config";

export async function getArchive(): Promise<ArchiveEntry[]> {
  return apiGet<ArchiveEntry[]>("/archive");
}

export async function archivePatient(payload: ArchivePayload): Promise<ArchiveEntry> {
  return apiPost<ArchiveEntry>("/archive", payload);
}

export async function restorePatient(archiveId: number): Promise<void> {
  await apiDelete(`/archive/${archiveId}`);
}
```

---

### Step-by-step: `staff.service.ts`

**After (real):**
```typescript
import { apiGet } from "./config";

export async function getStaff(): Promise<string[]> {
  return apiGet<string[]>("/staff");
}
```

---

## 10. CORS Configuration

Because the frontend (e.g. `http://localhost:5173` or
`https://yourapp.ph`) and the backend (e.g.
`http://localhost:8000`) are on different origins,
your backend **must** send CORS headers.

**Required headers your backend must return:**

```
Access-Control-Allow-Origin: http://localhost:5173
Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS
Access-Control-Allow-Headers: Content-Type, Authorization
```

For production, replace the origin with your actual domain:
```
Access-Control-Allow-Origin: https://yourapp.ph
```

**Example CORS setup by backend language/framework:**

**Node.js / Express:**
```javascript
const cors = require("cors");
app.use(cors({
  origin: process.env.FRONTEND_URL,
  methods: ["GET","POST","PUT","PATCH","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));
```

**Python / FastAPI:**
```python
from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("FRONTEND_URL")],
    allow_methods=["*"],
    allow_headers=["Content-Type", "Authorization"],
)
```

**Python / Django REST Framework:**
```python
# settings.py
INSTALLED_APPS += ["corsheaders"]
MIDDLEWARE = ["corsheaders.middleware.CorsMiddleware", ...MIDDLEWARE]
CORS_ALLOWED_ORIGINS = ["https://yourapp.ph"]
```

**PHP / Laravel:**
```php
// config/cors.php
'allowed_origins' => [env('FRONTEND_URL', 'http://localhost:5173')],
'allowed_methods' => ['*'],
'allowed_headers' => ['Content-Type', 'Authorization'],
```

---

## 11. Authentication Flow

The frontend stores two items in `localStorage`:

| Key | Contents |
|---|---|
| `heart_token` | The JWT string returned by `/auth/login` |
| `heart_user` | The serialised `AuthUser` JSON object |

**Every API request** (except `/auth/login`) automatically
sends this header via `authHeaders()` in `config.ts`:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

Your backend must:
1. Validate the JWT on every protected endpoint
2. Return `401 Unauthorized` if the token is missing or expired
3. The frontend does NOT yet auto-redirect on 401 — you may want
   to add a response interceptor in `config.ts` to handle this:

```typescript
// In config.ts — add this inside apiGet, apiPost, etc.
if (res.status === 401) {
  tokenStorage.clear();
  window.location.href = "/";   // redirect to login
  throw new Error("Session expired. Please log in again.");
}
```

**Recommended JWT settings on the backend:**
- Algorithm: HS256 or RS256
- Expiry: 8 hours (one work shift)
- Payload should contain: `{ sub: staffId, role: staffRole, iat, exp }`

---

## 12. Logbook Auto-Tracking (Important)

The logbook is an **audit trail**. Every time a patient record
is created, edited, deleted, archived, or restored, a log entry
must be created. This is **not done automatically** — you must
call `addLogbookEntry()` in your component code alongside the
patient service call.

**Where to add these calls (in the Dashboard or modals):**

```typescript
import * as patientsService from "../../api/patients.service";
import { addLogbookEntry } from "../../api/logbook.service";
import { useAuth } from "../../context/AuthContext";

// Inside your component:
const { user } = useAuth();

// After saving an edited patient:
await patientsService.updatePatient(patient.id, updatedPatient);
await addLogbookEntry({
  staffUsername : user.fullName,
  action        : "Edit Record",
  patientName   : `${updatedPatient.firstName} ${updatedPatient.lastName}`,
  patientId     : updatedPatient.id,
});

// After creating a new patient:
const created = await patientsService.createPatient(newPatient);
await addLogbookEntry({
  staffUsername : user.fullName,
  action        : "Add Record",
  patientName   : `${created.firstName} ${created.lastName}`,
  patientId     : created.id,
});
```

The current mock implementations of the above are already
set up in `logbook.service.ts` — they will work automatically
once you switch to the real API block.

---

## 13. File Structure Reference

```
/
├── .env.example               ← copy this to .env
├── DATABASE_FIELDS.txt        ← complete field reference (~129 fields)
├── SETUP_GUIDE.md             ← this file
├── package.json               ← dependencies
├── vite.config.ts             ← build config, @ alias
│
├── src/
│   ├── api/                   ← ALL backend communication lives here
│   │   ├── config.ts          ← base URL, JWT headers, fetch helpers
│   │   ├── auth.service.ts    ← login, logout, update email/password
│   │   ├── patients.service.ts← CRUD + delete for patients
│   │   ├── logbook.service.ts ← get + add + update logbook entries
│   │   ├── archive.service.ts ← get + archive + restore patients
│   │   └── staff.service.ts   ← get list of staff usernames
│   │
│   ├── context/
│   │   └── AuthContext.tsx    ← global auth state (useAuth() hook)
│   │
│   └── app/
│       ├── App.tsx            ← root: wraps AuthProvider + RouterProvider
│       ├── routes.ts          ← "/" → LoginPage, "/dashboard" → Dashboard
│       │
│       └── components/
│           ├── mockData.ts             ← TypeScript interfaces + sample data
│           ├── LoginPage.tsx           ← login screen
│           ├── Dashboard.tsx           ← main shell + sidebar
│           ├── PatientInformation.tsx  ← patient list + search
│           ├── PatientMedicalProfile.tsx← full patient profile view
│           ├── PatientEditModal.tsx    ← edit patient record (all tabs)
│           ├── PatientRegistration.tsx ← ITR-6, ITR-5, ITMR, PCV forms
│           ├── PatientArchive.tsx      ← archived patients list
│           ├── LogbookActivity.tsx     ← audit log view
│           ├── ImmunizationStatusTab.tsx
│           ├── SettingsModal.tsx
│           └── HealthCenterLogo.tsx    ← self-contained SVG logo
│
└── styles/
    ├── fonts.css     ← font imports (Poppins)
    ├── index.css     ← global base styles
    ├── tailwind.css  ← Tailwind entry point
    └── theme.css     ← CSS custom properties / tokens
```

---

## 14. Deployment Checklist

Before going live, go through each item:

### Frontend (build & host)

- [ ] Run `pnpm run build` — check for 0 TypeScript errors
- [ ] Set `VITE_API_BASE_URL` to your production backend URL
  in your hosting platform's environment settings
- [ ] Upload the contents of `dist/` to your web server
- [ ] Configure your web server to serve `index.html` for all
  routes (needed for React Router client-side routing):

  **Nginx example:**
  ```nginx
  location / {
    try_files $uri $uri/ /index.html;
  }
  ```

  **Apache `.htaccess` example:**
  ```apache
  RewriteEngine On
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^ /index.html [L]
  ```

### Backend

- [ ] All 13 API endpoints are implemented and returning
  the correct response shapes (see Section 7)
- [ ] CORS is configured with the correct frontend origin
- [ ] JWT secret key is stored in an environment variable
  (never hard-coded)
- [ ] Passwords are hashed with bcrypt or Argon2 — never
  stored as plain text
- [ ] Database is running and all 7 tables are created
- [ ] At least one staff account exists in `staff_accounts`

### Switching mock → real API

- [ ] `auth.service.ts` — MOCK block removed, REAL block enabled
- [ ] `patients.service.ts` — MOCK block removed, REAL block enabled
- [ ] `logbook.service.ts` — MOCK block removed, REAL block enabled
- [ ] `archive.service.ts` — MOCK block removed, REAL block enabled
- [ ] `staff.service.ts` — MOCK block removed, REAL block enabled
- [ ] `src/app/components/mockData.ts` — `mockPatients` array can
  be reduced to just the TypeScript interfaces (keep the types,
  remove the sample data array if you want a clean slate)

### Security reminders

- [ ] Use HTTPS in production (SSL certificate via Let's Encrypt)
- [ ] Rotate the JWT secret key — never reuse a default/demo key
- [ ] Do not expose `/DATABASE_FIELDS.txt` or `/SETUP_GUIDE.md`
  publicly on the production server
- [ ] Set up database backups

---

*End of SETUP_GUIDE.md*
*For field-level database reference, see DATABASE_FIELDS.txt*
*For the TypeScript type definitions, see src/app/components/mockData.ts*
