import { useState } from "react";
import { X, User, MapPin, Phone, Activity, Heart, Clock, Pill, CheckCircle2, XCircle, MinusCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Patient, PhysicalExamFindings } from "./mockData";
import { ImmunizationStatusTab } from "./ImmunizationStatusTab";

interface PatientMedicalProfileProps {
  patient: Patient;
  onClose: () => void;
  timeline?: string;
}

const FAMILY_HISTORY_ALL = [
  "Asthma/Allergies", "Birth Defects", "Cancer", "Dementia",
  "Diabetes", "Hypertension", "Lung Disease", "Mental Illness",
];

const SHEENT_OPTIONS = ["Pallor/Cyanosis", "Poor Skin Turgor", "Sunken Eyeball", "Sunken Fontanelle", "Icteric Sclerae", "Pale Conjunctivae", "Poor Vision", "Deafness", "Ear Discharges", "Nasal Congestion", "Lymphadenopathy", "Dental Caries", "Neck Mass"];
const CHEST_OPTIONS = ["Asymmetrical Expansion", "Chest Retraction", "Breast Discharge/Lump", "Crackles/Rales/Wheeze"];
const HEART_OPTIONS = ["Precordial Bulge", "Chest Pain", "Orthopnea"];
const ABDOMEN_OPTIONS = ["Bloody Stool", "Nausea", "Constipation", "Anorexia"];
const GU_OPTIONS = ["Frequency/Urgency", "Dysuria/Polyuria", "Abnormal Discharge", "Bloody Discharge"];
const EXTREMITIES_OPTIONS = ["Nail Clubbing", "Back/Joint Pain", "Joint Swelling", "Lymphedema"];
const NEURO_OPTIONS = ["Abnormal Gait", "Tremor/Seizure", "Numbness/Weakness", "Anxiety/Depression"];

type TabKey = "identifying" | "medical" | "physical" | "maternal" | "immunization";

function YesNo({ value }: { value: boolean }) {
  return value
    ? <span className="inline-flex items-center gap-1 text-green-600 font-semibold text-xs"><CheckCircle2 size={13} /> YES</span>
    : <span className="inline-flex items-center gap-1 text-red-400 font-semibold text-xs"><XCircle size={13} /> NO</span>;
}

function TriBadge({ value }: { value: string }) {
  if (value === "YES") return <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-semibold">YES</span>;
  if (value === "NO") return <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-600 text-xs font-semibold">NO</span>;
  return <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-500 text-xs font-semibold">N/A</span>;
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h4 className="text-[#004b96] font-bold text-xs uppercase tracking-wider mb-2 pb-1.5 border-b-2 border-[#004b96]/20">
      {children}
    </h4>
  );
}

function ExamSystem({ title, data, options }: { title: string; data: PhysicalExamFindings; options: string[] }) {
  return (
    <div className="bg-gray-50 rounded-lg p-3">
      <p className="font-semibold text-xs text-gray-700 mb-2 uppercase tracking-wide">{title}</p>
      {data.essentiallyNormal && data.findings.length === 0 ? (
        <span className="inline-flex items-center gap-1 text-green-600 text-xs font-medium">
          <CheckCircle2 size={13} /> Essentially Normal
        </span>
      ) : (
        <div className="flex flex-wrap gap-1.5">
          {data.essentiallyNormal && (
            <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-medium">Essentially Normal</span>
          )}
          {options.map((opt) => {
            const active = data.findings.includes(opt);
            return active ? (
              <span key={opt} className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-medium">{opt}</span>
            ) : null;
          })}
          {data.othersSpecify && (
            <span className="px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-800 text-xs font-medium">
              Other: {data.othersSpecify}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

export function PatientMedicalProfile({ patient, onClose, timeline }: PatientMedicalProfileProps) {
  const [activeTab, setActiveTab] = useState<TabKey>("identifying");
  const hasMaternalRecord = !!patient.maternalRecord;

  const tabs: { key: TabKey; label: string }[] = [
    { key: "identifying",  label: "Identifying Data" },
    { key: "medical",      label: "Medical History" },
    { key: "physical",     label: "Physical Exam" },
    { key: "immunization", label: "Immunization Status" },
    ...(hasMaternalRecord ? [{ key: "maternal" as TabKey, label: "Maternal Record" }] : []),
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
    >
      <motion.div
        initial={{ scale: 0.92, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.92, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 340, damping: 28 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[92vh] flex flex-col"
        style={{ fontFamily: "'Poppins', sans-serif" }}
      >
        {/* Header */}
        <div className="bg-[#004b96] rounded-t-2xl px-6 py-4 flex items-center justify-between flex-shrink-0">
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.15, duration: 0.3 }}
            className="flex items-center gap-3"
          >
            <div className="bg-white/20 rounded-full p-2">
              <User size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold text-xl">
                {patient.firstName} {patient.lastName}
              </h2>
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-white/80 text-sm">Patient Medical Profile</p>
                {timeline && (
                  <>
                    <span className="text-white/40 text-sm">|</span>
                    <p className="text-white/70 text-xs">{timeline}</p>
                  </>
                )}
              </div>
            </div>
          </motion.div>
          <motion.button
            onClick={onClose}
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            transition={{ type: "spring", stiffness: 400, damping: 20 }}
            className="text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full p-2 transition-colors"
          >
            <X size={20} />
          </motion.button>
        </div>

        {/* Vital Signs Bar */}
        <div className="px-6 pt-4 pb-2 flex-shrink-0">
          <div className={`grid gap-3 ${timeline ? "grid-cols-2" : "grid-cols-3"}`}>
            {[
              { icon: <Activity size={20} className="text-[#004b96] flex-shrink-0" />, label: "Blood Pressure", value: patient.bloodPressure },
              { icon: <Heart size={20} className="text-[#004b96] flex-shrink-0" />, label: "Weight", value: patient.weight },
              ...(!timeline ? [{ icon: <Clock size={20} className="text-[#004b96] flex-shrink-0" />, label: "Last Visit", value: patient.lastVisit }] : []),
            ].map((card, i) => (
              <motion.div
                key={card.label}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.18 + i * 0.07, duration: 0.3 }}
                className="bg-[#e8f4fd] rounded-xl p-3 flex items-center gap-3"
              >
                {card.icon}
                <div>
                  <p className="text-xs text-gray-500">{card.label}</p>
                  <p className="font-semibold text-[#004b96] text-sm">{card.value}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="px-6 flex-shrink-0">
          <div className="flex gap-1 border-b border-gray-200">
            {tabs.map((tab, i) => (
              <motion.button
                key={tab.key}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + i * 0.05 }}
                onClick={() => setActiveTab(tab.key)}
                className={`px-4 py-2 text-xs font-semibold transition-colors border-b-2 -mb-px whitespace-nowrap ${
                  activeTab === tab.key
                    ? "border-[#004b96] text-[#004b96]"
                    : "border-transparent text-gray-500 hover:text-[#004b96]"
                }`}
              >
                {tab.label}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
            >
              {/* ── TAB 1: Identifying Data ── */}
              {activeTab === "identifying" && (
                <>
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Identifying Data</SectionTitle>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Last Name:</span>
                        <span className="font-medium">{patient.lastName}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">First Name:</span>
                        <span className="font-medium">{patient.firstName}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">M.I.:</span>
                        <span className="font-medium">{patient.middleInitial}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Age:</span>
                        <span className="font-medium">{patient.age} years old</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Sex:</span>
                        <span className="font-medium">{patient.sex}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Birthday:</span>
                        <span className="font-medium">{patient.birthday}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Religion:</span>
                        <span className="font-medium">{patient.religion}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Civil Status:</span>
                        <span className="font-medium">{patient.civilStatus}</span>
                      </div>
                      <div className="flex gap-2 col-span-2 items-start">
                        <MapPin size={14} className="text-gray-400 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-500 min-w-[90px]">Address:</span>
                        <span className="font-medium">{patient.address}, {patient.barangay}, {patient.city}</span>
                      </div>
                      <div className="flex gap-2 items-center">
                        <Phone size={14} className="text-gray-400 flex-shrink-0" />
                        <span className="text-gray-500 min-w-[90px]">Contact:</span>
                        <span className="font-medium">{patient.contactNumber}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Education:</span>
                        <span className="font-medium">{patient.educationalAttainment}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Occupation:</span>
                        <span className="font-medium">{patient.occupation}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Purok:</span>
                        <span className="font-medium">{patient.purok}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Program:</span>
                        <span className="font-medium text-[#004b96]">{patient.program}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 min-w-[100px]">Children:</span>
                        <span className="font-medium">{patient.children}</span>
                      </div>
                    </div>
                  </div>

                  {patient.spouseName && (
                    <div className="border border-gray-200 rounded-xl p-4">
                      <SectionTitle>Spouse Name</SectionTitle>
                      <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
                        <div className="flex gap-2">
                          <span className="text-gray-500 min-w-[100px]">Spouse:</span>
                          <span className="font-medium">{patient.spouseName}</span>
                        </div>
                        {patient.spouseOccupation && (
                          <div className="flex gap-2">
                            <span className="text-gray-500 min-w-[100px]">Occupation:</span>
                            <span className="font-medium">{patient.spouseOccupation}</span>
                          </div>
                        )}
                        {patient.spouseContact && (
                          <div className="flex gap-2">
                            <span className="text-gray-500 min-w-[100px]">Contact:</span>
                            <span className="font-medium">{patient.spouseContact}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* ── TAB 2: Medical History ── */}
              {activeTab === "medical" && (
                <>
                  {/* Past Medical History */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Past Medical History</SectionTitle>
                    <div className="space-y-3 text-sm">
                      <div>
                        <p className="text-gray-500 font-medium text-xs mb-1">CO-MORBIDITIES:</p>
                        <p className="text-gray-800 ml-2">{patient.coMorbidities}</p>
                        <p className="text-gray-500 text-xs ml-4 mt-0.5">Allergies: <span className="text-gray-700 font-medium">{patient.allergies}</span></p>
                      </div>
                      <div className="flex gap-2">
                        <Pill size={14} className="text-gray-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-gray-500 font-medium text-xs mb-1">MAINTENANCE MEDICATION, DOSE & FREQUENCY:</p>
                          <p className="text-gray-800 ml-2">{patient.maintenanceMedication}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-gray-500 font-medium text-xs mb-1">PREVIOUS ILLNESSES / SURGERIES:</p>
                        <p className="text-gray-800 ml-2">{patient.previousIllnesses}</p>
                      </div>
                    </div>
                  </div>

                  {/* Family History */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Family History</SectionTitle>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                      {FAMILY_HISTORY_ALL.map((cond) => {
                        const has = patient.familyHistoryConditions.includes(cond);
                        return (
                          <div
                            key={cond}
                            className={`flex items-center gap-2 rounded-lg px-3 py-2 border text-xs font-medium ${
                              has
                                ? "bg-red-50 border-red-200 text-red-700"
                                : "bg-gray-50 border-gray-200 text-gray-400"
                            }`}
                          >
                            {has
                              ? <CheckCircle2 size={13} className="text-red-500 flex-shrink-0" />
                              : <MinusCircle size={13} className="text-gray-300 flex-shrink-0" />
                            }
                            {cond}
                          </div>
                        );
                      })}
                    </div>
                    {patient.familyHistoryOther && (
                      <p className="text-xs text-gray-600 mt-1">
                        <span className="font-semibold">Others:</span> {patient.familyHistoryOther}
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2 text-xs text-gray-600">
                      <span className="font-semibold">Mother:</span>
                      <TriBadge value={patient.familyHistoryMother} />
                    </div>
                  </div>

                  {/* Personal / Social History */}
                  {patient.personalSocialHistory && (
                    <div className="border border-gray-200 rounded-xl p-4">
                      <SectionTitle>Personal / Social History</SectionTitle>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                        {[
                          { label: "Eats Healthy Diet", value: patient.personalSocialHistory.eatsHealthyDiet },
                          { label: "Adequate Physical Activity", value: patient.personalSocialHistory.adequatePhysicalActivity },
                          { label: "Sufficient Rest / Sleep", value: patient.personalSocialHistory.sufficientRestSleep },
                          { label: "Normal Growth and Development", value: patient.personalSocialHistory.normalGrowthDevelopment },
                          { label: "Engage with Multiple Sex Partners", value: patient.personalSocialHistory.multiplePartners },
                        ].map((row) => (
                          <div key={row.label} className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                            <span className="text-gray-600 text-xs">{row.label}</span>
                            <YesNo value={row.value} />
                          </div>
                        ))}
                        <div className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                          <span className="text-gray-600 text-xs">
                            Smokes Tobacco
                            {patient.personalSocialHistory.smokesTobacco && patient.personalSocialHistory.tobaccoPacksPerYear > 0
                              ? ` (${patient.personalSocialHistory.tobaccoPacksPerYear} pack/yr)`
                              : ""}
                          </span>
                          <YesNo value={patient.personalSocialHistory.smokesTobacco} />
                        </div>
                        <div className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                          <span className="text-gray-600 text-xs">
                            Drinks Alcohol
                            {patient.personalSocialHistory.drinksAlcohol && patient.personalSocialHistory.alcoholBottlesPerYear > 0
                              ? ` (${patient.personalSocialHistory.alcoholBottlesPerYear} bottles/yr)`
                              : ""}
                          </span>
                          <YesNo value={patient.personalSocialHistory.drinksAlcohol} />
                        </div>
                        <div className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                          <span className="text-gray-600 text-xs">
                            Takes Illegal Drugs
                            {patient.personalSocialHistory.takesIllegalDrugs && patient.personalSocialHistory.illegalDrugsSpecify
                              ? ` (${patient.personalSocialHistory.illegalDrugsSpecify})`
                              : ""}
                          </span>
                          <YesNo value={patient.personalSocialHistory.takesIllegalDrugs} />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Health Programs */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Health Programs & Vaccines</SectionTitle>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
                      <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
                        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${patient.familyPlanning ? "bg-green-500" : "bg-gray-300"}`} />
                        <span className="text-xs text-gray-600">Family Planning: <span className="font-medium text-gray-800">{patient.familyPlanning ? "Enrolled" : "Not Enrolled"}</span></span>
                      </div>
                      <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
                        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${patient.vitamins ? "bg-green-500" : "bg-gray-300"}`} />
                        <span className="text-xs text-gray-600">Vitamins: <span className="font-medium text-gray-800">{patient.vitamins ? "Taking" : "Not Taking"}</span></span>
                      </div>
                      <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
                        <span className="text-xs text-gray-500">BCG:</span>
                        <TriBadge value={patient.bcgVaccine} />
                      </div>
                      <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
                        <span className="text-xs text-gray-500">Hep B:</span>
                        <TriBadge value={patient.hepBVaccine} />
                      </div>
                      <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
                        <span className="text-xs text-gray-500">Vitamin K:</span>
                        <TriBadge value={patient.vitaminK} />
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* ── TAB 3: Physical Exam ── */}
              {activeTab === "physical" && patient.physicalExam && (
                <>
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Physical Examination Findings</SectionTitle>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <ExamSystem title="SHEENT" data={patient.physicalExam.sheent} options={SHEENT_OPTIONS} />
                      <ExamSystem title="Chest, Breast & Lungs" data={patient.physicalExam.chestBreastLungs} options={CHEST_OPTIONS} />
                      <ExamSystem title="Heart" data={patient.physicalExam.heart} options={HEART_OPTIONS} />
                      <ExamSystem title="Abdomen" data={patient.physicalExam.abdomen} options={ABDOMEN_OPTIONS} />
                      <ExamSystem title="Genitourinary" data={patient.physicalExam.genitourinary} options={GU_OPTIONS} />
                      <ExamSystem title="Extremities" data={patient.physicalExam.extremities} options={EXTREMITIES_OPTIONS} />
                      <ExamSystem title="Neurological" data={patient.physicalExam.neurological} options={NEURO_OPTIONS} />
                    </div>
                  </div>
                </>
              )}

              {!patient.physicalExam && activeTab === "physical" && (
                <div className="text-center py-10 text-gray-400 text-sm">No physical exam data recorded.</div>
              )}

              {/* ── TAB: Immunization Status ── */}
              {activeTab === "immunization" && (
                <ImmunizationStatusTab patient={patient} />
              )}

              {/* ── TAB 4: Maternal Record ── */}
              {activeTab === "maternal" && patient.maternalRecord && (
                <>
                  {/* OB Score */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>OB Score</SectionTitle>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
                      {[
                        { label: "G", value: patient.maternalRecord.g },
                        { label: "P", value: patient.maternalRecord.p },
                        { label: "Full Term", value: patient.maternalRecord.fullTerm },
                        { label: "Preterm", value: patient.maternalRecord.preterm },
                        { label: "Abortion", value: patient.maternalRecord.abortion },
                        { label: "Living", value: patient.maternalRecord.living },
                      ].map((item) => (
                        <div key={item.label} className="bg-[#e8f4fd] rounded-lg py-2 px-3">
                          <p className="text-[10px] text-gray-500 font-medium">{item.label}</p>
                          <p className="text-[#004b96] font-bold text-lg leading-tight">{item.value}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Gynecological History */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Gynecological History</SectionTitle>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-2 text-sm">
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[110px]">Menarche Age:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.menarcheAge} years old</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[110px]">Menstrual Cycle:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.menstrualCycle}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[110px]">Menstrual Flow:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.menstrualFlowDays} days</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[110px]">Coitarche Age:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.coitarcheAge} years old</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[110px]">Current FP Method:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.currentFpMethod}</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
                      {[
                        { label: "PAP Smear", done: patient.maternalRecord.papSmear, date: patient.maternalRecord.papSmearDate, result: patient.maternalRecord.papSmearResult },
                        { label: "VIA", done: patient.maternalRecord.via, date: patient.maternalRecord.viaDate, result: patient.maternalRecord.viaResult },
                        { label: "History of STI", done: patient.maternalRecord.historyOfSti, date: patient.maternalRecord.stiDate, result: patient.maternalRecord.stiResult },
                      ].map((item) => (
                        <div key={item.label} className="bg-gray-50 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-semibold text-gray-700">{item.label}</span>
                            <YesNo value={item.done} />
                          </div>
                          {item.done && item.date && (
                            <p className="text-xs text-gray-500">Date: <span className="text-gray-700 font-medium">{item.date}</span></p>
                          )}
                          {item.done && item.result && (
                            <p className="text-xs text-gray-500">Result: <span className="text-gray-700 font-medium">{item.result}</span></p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Prenatal Care */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Prenatal Care — Details of Present Pregnancy</SectionTitle>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm mb-3">
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Risk Code:</span>
                        <span className="font-medium text-xs text-orange-600">{patient.maternalRecord.riskCode}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Mother-Baby Book:</span>
                        <YesNo value={patient.maternalRecord.motherBabyBook} />
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Last Menstrual Period:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.lmp}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Expected Date of Delivery:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.edd}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Age of Gestation:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.ageOfGestation}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Plan to Deliver At:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.planToDeliverAt}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-gray-500 text-xs min-w-[120px]">Accompanying Person:</span>
                        <span className="font-medium text-xs">{patient.maternalRecord.accompanyingPerson}</span>
                      </div>
                    </div>

                    {/* Dentist & Physician */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-semibold text-gray-700">Seen by Dentist</span>
                          <YesNo value={patient.maternalRecord.seenByDentist} />
                        </div>
                        {patient.maternalRecord.seenByDentist && (
                          <>
                            <p className="text-xs text-gray-500">Date: <span className="font-medium text-gray-700">{patient.maternalRecord.dentistDate}</span></p>
                            <p className="text-xs text-gray-500 mt-0.5">
                              Visits — 1st Trimester: <span className="font-medium text-gray-700">{patient.maternalRecord.dentistVisits.first}</span>{" "}
                              · 2nd: <span className="font-medium text-gray-700">{patient.maternalRecord.dentistVisits.second}</span>{" "}
                              · 3rd: <span className="font-medium text-gray-700">{patient.maternalRecord.dentistVisits.third}</span>
                            </p>
                          </>
                        )}
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-semibold text-gray-700">Seen by Physician</span>
                          <YesNo value={patient.maternalRecord.seenByPhysician} />
                        </div>
                        {patient.maternalRecord.seenByPhysician && (
                          <>
                            <p className="text-xs text-gray-500">Date: <span className="font-medium text-gray-700">{patient.maternalRecord.physicianDate}</span></p>
                            {patient.maternalRecord.physicianVisits && (
                              <p className="text-xs text-gray-500 mt-0.5">
                                Visits — 1st Trimester: <span className="font-medium text-gray-700">{patient.maternalRecord.physicianVisits.first}</span>{" "}
                                · 2nd: <span className="font-medium text-gray-700">{patient.maternalRecord.physicianVisits.second}</span>{" "}
                                · 3rd: <span className="font-medium text-gray-700">{patient.maternalRecord.physicianVisits.third}</span>
                              </p>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Tetanus Toxoid Status */}
                  <div className="border border-gray-200 rounded-xl p-4">
                    <SectionTitle>Tetanus Toxoid Status & Date</SectionTitle>
                    <div className="grid grid-cols-5 gap-2">
                      {(["tt1", "tt2", "tt3", "tt4", "tt5"] as const).map((key, i) => (
                        <div key={key} className="bg-gray-50 rounded-lg p-2 text-center">
                          <p className="text-xs font-bold text-[#004b96]">TT{i + 1}</p>
                          <p className="text-xs text-gray-600 mt-0.5">
                            {patient.maternalRecord![key] || <span className="text-gray-300">—</span>}
                          </p>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-4 mt-3">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-gray-500">Iodized Salt:</span>
                        <YesNo value={patient.maternalRecord.iodizedSalt} />
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-gray-500">Iron Supplement:</span>
                        <YesNo value={patient.maternalRecord.ironSupplement} />
                      </div>
                    </div>
                  </div>
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  );
}