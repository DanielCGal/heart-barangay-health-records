import { useState, useRef, useEffect } from "react";
import { CheckCircle2, ChevronDown, AlertCircle, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import type { Patient } from "./mockData";
import * as patientsService from "../../api/patients.service";
import { addLogbookEntry } from "../../api/logbook.service";
import { useAuth } from "../../context/AuthContext";

type RegistrationTab = "ITR_6" | "ITR_5" | "ITMR" | "PCV";

// ── Shared exam types ──────────────────────────────────────────────────────
interface ExamSection { normal: boolean; findings: string[]; other: string; }
interface PhysicalExamForm {
  sheent: ExamSection; chest: ExamSection; heart: ExamSection;
  abdomen: ExamSection; genitourinary: ExamSection;
  extremities: ExamSection; neurological: ExamSection;
}
const blankExam = (): ExamSection => ({ normal: true, findings: [], other: "" });
const blankPhysicalExam = (): PhysicalExamForm => ({
  sheent: blankExam(), chest: blankExam(), heart: blankExam(),
  abdomen: blankExam(), genitourinary: blankExam(),
  extremities: blankExam(), neurological: blankExam(),
});

const SHEENT_OPTIONS      = ["Pallor/Cyanosis","Poor Skin Turgor","Sunken Eyeball","Sunken Fontanelle","Icteric Sclerae","Pale Conjunctivae","Poor Vision","Deafness","Ear Discharges","Nasal Congestion","Lymphadenopathy","Dental Caries","Neck Mass"];
const CHEST_OPTIONS       = ["Asymmetrical Expansion","Chest Retraction","Breast Discharge/Lump","Crackles/Rales/Wheeze"];
const HEART_OPTIONS       = ["Precordial Bulge","Chest Pain","Orthopnea"];
const ABDOMEN_OPTIONS     = ["Bloody Stool","Nausea","Constipation","Anorexia"];
const GU_OPTIONS          = ["Frequency/Urgency","Dysuria/Polyuria","Abnormal Discharge","Bloody Discharge"];
const EXTREMITIES_OPTIONS = ["Nail Clubbing","Back/Joint Pain","Joint Swelling","Lymphedema"];
const NEURO_OPTIONS       = ["Abnormal Gait","Tremor/Seizure","Numbness/Weakness","Anxiety/Depression"];
const FAMILY_CONDITIONS   = ["Asthma/Allergies","Birth Defects","Cancer","Dementia","Diabetes","Hypertension","Lung Disease","Mental Illness"];

const MONTHS_REG = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const TT_YEARS_REG = Array.from({ length: 17 }, (_, i) => String(2026 - i));
function parseTTReg(tt: string): { month: string; year: string } {
  if (!tt) return { month: "", year: "" };
  const parts = tt.trim().split(" ");
  return { month: parts[0] || "", year: parts[1] || "" };
}
function formatTTReg(month: string, year: string): string {
  if (month && year) return `${month} ${year}`;
  return month || year || "";
}

// ── Co-morbidity state ─────────────────────────────────────────────────────
interface CoMorbState {
  hasAny: boolean;
  // Adult-only conditions
  hypertension: boolean;
  diabetes: boolean;
  stiHiv: boolean;
  heartDisease: boolean;
  kidneyFailure: boolean;
  tb: boolean;
  // All ages
  allergies: boolean; allergiesSpecify: string;
  cancer: boolean; cancerSpecify: string;
  others: boolean; othersSpecify: string;
}
const blankCoMorb = (): CoMorbState => ({
  hasAny: false,
  hypertension: false, diabetes: false, stiHiv: false,
  heartDisease: false, kidneyFailure: false, tb: false,
  allergies: false, allergiesSpecify: "",
  cancer: false, cancerSpecify: "", others: false, othersSpecify: "",
});

// ── ITR 6 form ─────────────────────────────────────────────────────────────
interface ITR6Form {
  lastName: string; firstName: string; mi: string;
  ageYears: string; ageMonths: string;
  sex: string; birthday: string; religion: string;
  barangay: string; city: string; address: string;
  coMorb: CoMorbState; maintenanceMed: string; previousIllnesses: string;
  familyHistory: string[]; familyHistoryOther: string;
  eatsHealthy: boolean; adequateActivity: boolean; sufficientRest: boolean;
  normalGrowth: boolean; multiplePartners: boolean;
  smokesTobacco: boolean; tobaccoPacks: string;
  drinksAlcohol: boolean; alcoholBottles: string;
  illegalDrugs: boolean; illegalDrugsSpecify: string;
  physicalExam: PhysicalExamForm;
  agreedToTerms: boolean;
}
const blankITR6 = (): ITR6Form => ({
  lastName: "", firstName: "", mi: "", ageYears: "", ageMonths: "",
  sex: "", birthday: "", religion: "", barangay: "", city: "", address: "",
  coMorb: blankCoMorb(), maintenanceMed: "", previousIllnesses: "",
  familyHistory: [], familyHistoryOther: "",
  eatsHealthy: false, adequateActivity: false, sufficientRest: false,
  normalGrowth: false, multiplePartners: false,
  smokesTobacco: false, tobaccoPacks: "",
  drinksAlcohol: false, alcoholBottles: "",
  illegalDrugs: false, illegalDrugsSpecify: "",
  physicalExam: blankPhysicalExam(),
  agreedToTerms: false,
});

// ── ITR 5 form ─────────────────────────────────────────────────────────────
interface ITR5Form {
  lastName: string; firstName: string; mi: string;
  ageYears: string; ageMonths: string;
  sex: string; birthday: string; religion: string;
  barangay: string; city: string; address: string;
  coMorb: CoMorbState; maintenanceMed: string; previousIllnesses: string;
  typeOfDelivery: string;
  birthWeight: string; birthHeight: string; currentWeight: string; currentHeight: string;
  bcgVaccine: boolean; bcgDate: string;
  hepBVaccine: boolean; hepBDate: string;
  vitaminK: boolean; vitaminKDate: string;
  motherTetanusShots: string;
  newbornScreening: boolean; screeningDate: string; screeningResults: string;
  initiatedBreastfeeding: boolean; breastfeedingDate: string;
  placeOfDelivery: string;
  familyHistory: string[]; familyHistoryOther: string;
  livesWithFamily: boolean; uneventfulBirth: boolean; normalGrowth: boolean;
  normalMoods: boolean; normalInterestFamily: boolean; normalInterestWork: boolean;
  adequateActivity: boolean; sufficientRest: boolean; socialOther: string;
  physicalExam: PhysicalExamForm;
  agreedToTerms: boolean;
}
const blankITR5 = (): ITR5Form => ({
  lastName: "", firstName: "", mi: "", ageYears: "", ageMonths: "",
  sex: "", birthday: "", religion: "", barangay: "", city: "", address: "",
  coMorb: blankCoMorb(), maintenanceMed: "", previousIllnesses: "",
  typeOfDelivery: "", birthWeight: "", birthHeight: "", currentWeight: "", currentHeight: "",
  bcgVaccine: false, bcgDate: "", hepBVaccine: false, hepBDate: "",
  vitaminK: false, vitaminKDate: "", motherTetanusShots: "",
  newbornScreening: false, screeningDate: "", screeningResults: "",
  initiatedBreastfeeding: false, breastfeedingDate: "", placeOfDelivery: "",
  familyHistory: [], familyHistoryOther: "",
  livesWithFamily: false, uneventfulBirth: false, normalGrowth: false,
  normalMoods: false, normalInterestFamily: false, normalInterestWork: false,
  adequateActivity: false, sufficientRest: false, socialOther: "",
  physicalExam: blankPhysicalExam(),
  agreedToTerms: false,
});

// ── ITMR form ──────────────────────────────────────────────────────────────
interface ITMRForm {
  patientName: string;
  g: string; p: string; fullTerm: string; preterm: string; abortion: string; living: string;
  menarcheAge: string; menstrualCycle: string; menstrualFlowDays: string;
  coitarcheAge: string; currentFpMethod: string;
  papSmear: boolean; papSmearDate: string; papSmearResult: string;
  via: boolean; viaDate: string; viaResult: string;
  historyOfSti: boolean; stiDate: string; stiResult: string;
  riskCode: string; motherBabyBook: boolean;
  lmp: string; edd: string; planToDeliverAt: string; ageOfGestation: string; accompanyingPerson: string;
  seenByDentist: boolean; dentistDate: string;
  dentistFirst: string; dentistSecond: string; dentistThird: string;
  seenByPhysician: boolean; physicianDate: string;
  physicianFirst: string; physicianSecond: string; physicianThird: string;
  tt1: string; tt2: string; tt3: string; tt4: string; tt5: string;
  iodizedSalt: boolean; ironSupplement: boolean;
  agreedToTerms: boolean;
}
const blankITMR = (): ITMRForm => ({
  patientName: "",
  g: "", p: "", fullTerm: "", preterm: "", abortion: "", living: "",
  menarcheAge: "", menstrualCycle: "Regular", menstrualFlowDays: "",
  coitarcheAge: "", currentFpMethod: "",
  papSmear: false, papSmearDate: "", papSmearResult: "",
  via: false, viaDate: "", viaResult: "",
  historyOfSti: false, stiDate: "", stiResult: "",
  riskCode: "", motherBabyBook: false,
  lmp: "", edd: "", planToDeliverAt: "", ageOfGestation: "", accompanyingPerson: "",
  seenByDentist: false, dentistDate: "",
  dentistFirst: "", dentistSecond: "", dentistThird: "",
  seenByPhysician: false, physicianDate: "",
  physicianFirst: "", physicianSecond: "", physicianThird: "",
  tt1: "", tt2: "", tt3: "", tt4: "", tt5: "",
  iodizedSalt: false, ironSupplement: false,
  agreedToTerms: false,
});

// ── Shared styled atoms ────────────────────────────────────────────────────
const IC = "w-full border-b border-gray-400 bg-transparent text-sm focus:outline-none focus:border-[#004b96] py-0.5 placeholder-gray-400";
const LC = "text-[10px] font-semibold text-gray-500 uppercase tracking-wide";

function SectionBox({ title, children, delay = 0 }: { title: string; children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.32, ease: "easeOut", delay }}
      className="border border-black/15 rounded-xl p-4 mb-4"
    >
      <p className="font-bold text-[#004b96] text-xs uppercase tracking-wider mb-3 pb-2 border-b border-[#004b96]/20">
        {title}
      </p>
      {children}
    </motion.div>
  );
}

function YesNoRow({
  label, value, onChange,
}: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-gray-100 last:border-0">
      <span className="text-xs text-gray-700">{label}</span>
      <div className="flex gap-3">
        {[true, false].map((opt) => (
          <label key={String(opt)} className="flex items-center gap-1 cursor-pointer select-none">
            <div
              onClick={() => onChange(opt)}
              className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center transition-all ${
                value === opt ? "border-[#004b96] bg-[#004b96]" : "border-gray-400"
              }`}
            >
              {value === opt && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
            </div>
            <span className="text-[10px] font-semibold text-gray-500">{opt ? "YES" : "NO"}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

function ExamSystemField({
  title, data, options, onChange,
}: { title: string; data: ExamSection; options: string[]; onChange: (d: ExamSection) => void }) {
  const toggleFinding = (opt: string) => {
    const has = data.findings.includes(opt);
    const next = has ? data.findings.filter((f) => f !== opt) : [...data.findings, opt];
    onChange({ ...data, normal: next.length === 0, findings: next });
  };
  return (
    <div className="border border-gray-200 rounded-lg p-3 mb-2">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-bold text-gray-700 uppercase tracking-wide">{title}</span>
        <label className="flex items-center gap-1.5 cursor-pointer select-none text-[10px] font-semibold text-green-700">
          <input
            type="checkbox"
            checked={data.normal && data.findings.length === 0}
            onChange={(e) => onChange({ ...data, normal: e.target.checked, findings: e.target.checked ? [] : data.findings })}
            className="accent-green-600"
          />
          Essentially Normal
        </label>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {options.map((opt) => {
          const active = data.findings.includes(opt);
          return (
            <button
              key={opt}
              type="button"
              onClick={() => toggleFinding(opt)}
              className={`px-2 py-0.5 rounded-full text-[10px] border transition-all ${
                active ? "bg-[#004b96] text-white border-[#004b96]" : "bg-gray-50 text-gray-500 border-gray-300 hover:border-[#004b96]/50"
              }`}
            >
              {opt}
            </button>
          );
        })}
      </div>
      {!data.normal && (
        <div className="mt-2">
          <label className={LC}>Others, specify:</label>
          <input className={IC} value={data.other} onChange={(e) => onChange({ ...data, other: e.target.value })} placeholder="Describe…" />
        </div>
      )}
    </div>
  );
}

function CoMorbSection({ data, onChange, isAdult = false }: { data: CoMorbState; onChange: (d: CoMorbState) => void; isAdult?: boolean }) {
  return (
    <div>
      <YesNoRow label="CO-MORBIDITIES" value={data.hasAny} onChange={(v) => onChange({ ...data, hasAny: v })} />
      {data.hasAny && (
        <div className="ml-4 mt-2 space-y-2 border-l-2 border-[#004b96]/20 pl-3">
          {isAdult && (
            <div>
              <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Select applicable conditions:</p>
              <div className="flex flex-wrap gap-1.5">
                {([
                  ["hypertension", "Hypertension"],
                  ["diabetes", "Diabetes"],
                  ["stiHiv", "STI/HIV"],
                  ["heartDisease", "Heart Disease"],
                  ["kidneyFailure", "Kidney Failure"],
                  ["tb", "TB"],
                ] as const).map(([key, label]) => {
                  const checked = data[key] as boolean;
                  return (
                    <label
                      key={key}
                      className={`flex items-center gap-1.5 cursor-pointer px-2.5 py-1.5 rounded-lg border text-[10px] font-semibold transition-all ${
                        checked ? "bg-[#004b96] text-white border-[#004b96]" : "bg-white text-gray-600 border-gray-200 hover:border-[#004b96]/50"
                      }`}
                    >
                      <input type="checkbox" className="sr-only" checked={checked} onChange={(e) => onChange({ ...data, [key]: e.target.checked })} />
                      <span className={`w-3 h-3 rounded border flex-shrink-0 flex items-center justify-center ${checked ? "bg-white border-white" : "border-current"}`}>
                        {checked && <svg viewBox="0 0 10 10" className="w-2 h-2 text-[#004b96]" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1.5 5l2.5 2.5 4.5-4.5" /></svg>}
                      </span>
                      {label}
                    </label>
                  );
                })}
              </div>
            </div>
          )}
          <div>
            <YesNoRow label="Allergies" value={data.allergies} onChange={(v) => onChange({ ...data, allergies: v })} />
            {data.allergies && (
              <div className="mt-1 ml-4"><label className={LC}>Specify:</label>
                <input className={IC} value={data.allergiesSpecify} onChange={(e) => onChange({ ...data, allergiesSpecify: e.target.value })} placeholder="e.g. Penicillin" />
              </div>
            )}
          </div>
          <div>
            <YesNoRow label="Cancer" value={data.cancer} onChange={(v) => onChange({ ...data, cancer: v })} />
            {data.cancer && (
              <div className="mt-1 ml-4"><label className={LC}>Specify:</label>
                <input className={IC} value={data.cancerSpecify} onChange={(e) => onChange({ ...data, cancerSpecify: e.target.value })} placeholder="Type of cancer…" />
              </div>
            )}
          </div>
          <div>
            <YesNoRow label="Others" value={data.others} onChange={(v) => onChange({ ...data, others: v })} />
            {data.others && (
              <div className="mt-1 ml-4"><label className={LC}>Specify:</label>
                <input className={IC} value={data.othersSpecify} onChange={(e) => onChange({ ...data, othersSpecify: e.target.value })} placeholder="Other conditions…" />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function FamilyHistorySection({
  selected, other,
  onToggle, onOtherChange,
}: { selected: string[]; other: string; onToggle: (c: string) => void; onOtherChange: (v: string) => void }) {
  return (
    <div className="space-y-1">
      {FAMILY_CONDITIONS.map((cond) => {
        const checked = selected.includes(cond);
        return (
          <label key={cond} className="flex items-center gap-2 cursor-pointer py-1 border-b border-gray-100 last:border-0">
            <div
              onClick={() => onToggle(cond)}
              className={`w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                checked ? "bg-[#004b96] border-[#004b96]" : "border-gray-400"
              }`}
            >
              {checked && <CheckCircle2 size={10} className="text-white" />}
            </div>
            <span className="text-xs text-gray-700 flex-1">{cond}</span>
            <div className="flex gap-3">
              <span className={`text-[10px] font-bold ${checked ? "text-[#004b96]" : "text-gray-300"}`}>YES</span>
              <span className={`text-[10px] font-bold ${!checked ? "text-gray-500" : "text-gray-300"}`}>NO</span>
            </div>
          </label>
        );
      })}
      <div className="pt-1">
        <label className={LC}>Other, Specify:</label>
        <input className={IC} value={other} onChange={(e) => onOtherChange(e.target.value)} placeholder="e.g. Heart disease history" />
      </div>
    </div>
  );
}

function SaveBar({
  agreed, onAgree, onSave, saved, saving, error,
}: {
  agreed: boolean;
  onAgree: () => void;
  onSave: () => void;
  saved: boolean;
  saving: boolean;
  error: string | null;
}) {
  return (
    <div className="mt-4 pt-4 border-t border-gray-200 space-y-2">
      {error && (
        <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
          <AlertCircle size={14} className="text-red-500 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-red-600">{error}</p>
        </div>
      )}
      <div className="flex items-center justify-between">
        <label className="flex items-center gap-2 text-xs cursor-pointer select-none">
          <input type="checkbox" checked={agreed} onChange={onAgree} className="accent-[#004b96]" />
          <span>I agree to the <span className="text-[#004b96] underline">terms of service and Privacy Policy</span></span>
        </label>
        <button
          onClick={onSave}
          disabled={!agreed || saving}
          className={`px-8 py-2 rounded-full font-bold text-sm text-white transition-all flex items-center gap-2 ${
            saved
              ? "bg-green-600"
              : agreed && !saving
              ? "bg-[#004b96] hover:bg-[#003a75] shadow-md"
              : "bg-gray-300 cursor-not-allowed"
          }`}
        >
          {saving && <Loader2 size={14} className="animate-spin" />}
          {saved ? "SAVED!" : saving ? "SAVING…" : "SAVE"}
        </button>
      </div>
    </div>
  );
}

// ── Patient name dropdown for ITMR ─────────────────────────────────────────
function PatientNameDropdown({ value, onChange, patients }: {
  value: string;
  onChange: (v: string) => void;
  patients: Patient[];
}) {
  const femalePatients = patients.filter((p) => p.sex === "Female");
  const [query, setQuery] = useState(value);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const filtered = femalePatients.filter((p) => {
    const full = `${p.firstName} ${p.lastName}`.toLowerCase();
    return full.includes(query.toLowerCase()) || query === "";
  });

  const select = (p: Patient) => {
    const full = `${p.firstName} ${p.lastName}`;
    setQuery(full);
    onChange(full);
    setOpen(false);
  };

  return (
    <div className="relative" ref={ref}>
      <label className={LC}>NAME (Female Patients):</label>
      <div className="flex items-center border-b border-gray-400 focus-within:border-[#004b96]">
        <input
          className="flex-1 bg-transparent text-sm focus:outline-none py-0.5 placeholder-gray-400"
          value={query}
          onChange={(e) => { setQuery(e.target.value); onChange(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search patient name…"
        />
        <ChevronDown size={14} className={`text-gray-400 transition-transform ${open ? "rotate-180" : ""}`} />
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute top-full left-0 right-0 z-50 bg-white border border-gray-200 rounded-lg shadow-xl mt-1 max-h-48 overflow-y-auto">
          {filtered.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => select(p)}
              className="w-full text-left px-3 py-2 text-sm hover:bg-[#e8f4fd] transition-colors flex items-center justify-between gap-2"
            >
              <span className="font-medium text-gray-800">{p.firstName} {p.lastName}</span>
              <span className="text-[10px] text-gray-400 flex-shrink-0">{p.program}</span>
            </button>
          ))}
        </div>
      )}
      {open && filtered.length === 0 && query && (
        <div className="absolute top-full left-0 right-0 z-50 bg-white border border-gray-200 rounded-lg shadow-xl mt-1 px-3 py-2 text-xs text-gray-400">
          No female patients found
        </div>
      )}
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export function PatientRegistration() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<RegistrationTab>("ITR_6");
  const [itr6, setItr6] = useState<ITR6Form>(blankITR6);
  const [itr5, setItr5] = useState<ITR5Form>(blankITR5);
  const [itmr, setItmr] = useState<ITMRForm>(blankITMR);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [allPatients, setAllPatients] = useState<Patient[]>([]);

  // Load patients for the ITMR name dropdown
  useEffect(() => {
    patientsService.getPatients().then(setAllPatients).catch(console.error);
  }, []);

  const tabs: { key: RegistrationTab; label: string }[] = [
    { key: "ITR_6", label: "ITR FOR 6 YEARS OLD AND ABOVE" },
    { key: "ITR_5", label: "ITR FOR 5 YEARS OLD AND BELOW" },
    { key: "ITMR", label: "ADD NEW MATERNAL REGISTRATION" },
    { key: "PCV", label: "PCV" },
  ];

  // ── Helpers ────────────────────────────────────────────────────────────────
  function buildCoMorbString(coMorb: CoMorbState, isAdult: boolean): string {
    if (!coMorb.hasAny) return "None";
    const list: string[] = [];
    if (isAdult) {
      if (coMorb.hypertension)  list.push("Hypertension");
      if (coMorb.diabetes)      list.push("Diabetes");
      if (coMorb.stiHiv)        list.push("STI/HIV");
      if (coMorb.heartDisease)  list.push("Heart Disease");
      if (coMorb.kidneyFailure) list.push("Kidney Failure");
      if (coMorb.tb)            list.push("TB");
    }
    if (coMorb.others && coMorb.othersSpecify) list.push(coMorb.othersSpecify);
    return list.length > 0 ? list.join(", ") : "None";
  }

  function buildPhysicalExam(pe: PhysicalExamForm): Patient["physicalExam"] {
    const map = (s: ExamSection) => ({
      essentiallyNormal: s.normal && s.findings.length === 0,
      findings: s.findings,
      othersSpecify: s.other,
    });
    return {
      sheent:           map(pe.sheent),
      chestBreastLungs: map(pe.chest),
      heart:            map(pe.heart),
      abdomen:          map(pe.abdomen),
      genitourinary:    map(pe.genitourinary),
      extremities:      map(pe.extremities),
      neurological:     map(pe.neurological),
    };
  }

  // ── Mapper: ITR 6 → Patient ────────────────────────────────────────────────
  function mapITR6ToPatient(f: ITR6Form): Omit<Patient, "id"> {
    return {
      lastName:              f.lastName.trim(),
      firstName:             f.firstName.trim(),
      middleInitial:         f.mi.trim(),
      age:                   parseInt(f.ageYears) || 0,
      ageMonths:             parseInt(f.ageMonths) || 0,
      sex:                   (f.sex as "Male" | "Female") || "Male",
      birthday:              f.birthday,
      religion:              f.religion,
      barangay:              f.barangay,
      city:                  f.city,
      address:               f.address,
      purok:                 "",
      civilStatus:           "",
      contactNumber:         "",
      educationalAttainment: "",
      occupation:            "",
      program:               "Cardiovascular Disease",
      familyPlanning:        false,
      vitamins:              false,
      children:              0,
      coMorbidities:         buildCoMorbString(f.coMorb, true),
      cancer:                f.coMorb.cancer ? (f.coMorb.cancerSpecify.trim() || "Cancer") : "None",
      allergies:             f.coMorb.allergies ? (f.coMorb.allergiesSpecify.trim() || "Yes") : "None",
      maintenanceMedication: f.maintenanceMed,
      previousIllnesses:     f.previousIllnesses,
      lastVisit:             new Date().toISOString().split("T")[0],
      bloodPressure:         "",
      weight:                "",
      height:                "",
      bcgVaccine:            "N/A",
      hepBVaccine:           "N/A",
      vitaminK:              "N/A",
      familyHistoryConditions: f.familyHistory,
      familyHistoryOther:    f.familyHistoryOther,
      familyHistoryMother:   "N/A",
      personalSocialHistory: {
        eatsHealthyDiet:          f.eatsHealthy,
        adequatePhysicalActivity:  f.adequateActivity,
        sufficientRestSleep:       f.sufficientRest,
        normalGrowthDevelopment:   f.normalGrowth,
        multiplePartners:          f.multiplePartners,
        smokesTobacco:             f.smokesTobacco,
        tobaccoPacksPerYear:       parseFloat(f.tobaccoPacks) || 0,
        drinksAlcohol:             f.drinksAlcohol,
        alcoholBottlesPerYear:     parseFloat(f.alcoholBottles) || 0,
        takesIllegalDrugs:         f.illegalDrugs,
        illegalDrugsSpecify:       f.illegalDrugsSpecify,
      },
      physicalExam: buildPhysicalExam(f.physicalExam),
    };
  }

  // ── Mapper: ITR 5 → Patient ────────────────────────────────────────────────
  function mapITR5ToPatient(f: ITR5Form): Omit<Patient, "id"> {
    return {
      lastName:              f.lastName.trim(),
      firstName:             f.firstName.trim(),
      middleInitial:         f.mi.trim(),
      age:                   parseInt(f.ageYears) || 0,
      ageMonths:             parseInt(f.ageMonths) || 0,
      sex:                   (f.sex as "Male" | "Female") || "Male",
      birthday:              f.birthday,
      religion:              f.religion,
      barangay:              f.barangay,
      city:                  f.city,
      address:               f.address,
      purok:                 "",
      civilStatus:           "",
      contactNumber:         "",
      educationalAttainment: "",
      occupation:            "",
      program:               "National Immunization",
      familyPlanning:        false,
      vitamins:              false,
      children:              0,
      coMorbidities:         buildCoMorbString(f.coMorb, false),
      cancer:                f.coMorb.cancer ? (f.coMorb.cancerSpecify.trim() || "Cancer") : "None",
      allergies:             f.coMorb.allergies ? (f.coMorb.allergiesSpecify.trim() || "Yes") : "None",
      maintenanceMedication: f.maintenanceMed,
      previousIllnesses:     f.previousIllnesses,
      lastVisit:             new Date().toISOString().split("T")[0],
      bloodPressure:         "",
      weight:                f.currentWeight ? `${f.currentWeight} kg` : "",
      height:                f.currentHeight ? `${f.currentHeight} cm` : "",
      bcgVaccine:            f.bcgVaccine ? "YES" : "NO",
      hepBVaccine:           f.hepBVaccine ? "YES" : "NO",
      vitaminK:              f.vitaminK ? "YES" : "NO",
      familyHistoryConditions: f.familyHistory,
      familyHistoryOther:    f.familyHistoryOther,
      familyHistoryMother:   "N/A",
      personalSocialHistory: {
        eatsHealthyDiet:          false,
        adequatePhysicalActivity:  f.adequateActivity,
        sufficientRestSleep:       f.sufficientRest,
        normalGrowthDevelopment:   f.normalGrowth,
        multiplePartners:          false,
        smokesTobacco:             false,
        tobaccoPacksPerYear:       0,
        drinksAlcohol:             false,
        alcoholBottlesPerYear:     0,
        takesIllegalDrugs:         false,
        illegalDrugsSpecify:       "",
      },
      physicalExam: buildPhysicalExam(f.physicalExam),
    };
  }

  // ── Mapper: ITMR → MaternalRecord ─────────────────────────────────────────
  function buildMaternalRecord(f: ITMRForm): NonNullable<Patient["maternalRecord"]> {
    return {
      g:                parseInt(f.g) || 0,
      p:                parseInt(f.p) || 0,
      fullTerm:         parseInt(f.fullTerm) || 0,
      preterm:          parseInt(f.preterm) || 0,
      abortion:         parseInt(f.abortion) || 0,
      living:           parseInt(f.living) || 0,
      menarcheAge:      parseInt(f.menarcheAge) || 0,
      menstrualCycle:   (f.menstrualCycle as "Regular" | "Irregular"),
      menstrualFlowDays: parseInt(f.menstrualFlowDays) || 0,
      coitarcheAge:     parseInt(f.coitarcheAge) || 0,
      currentFpMethod:  f.currentFpMethod,
      papSmear:         f.papSmear,
      papSmearDate:     f.papSmearDate,
      papSmearResult:   f.papSmearResult,
      via:              f.via,
      viaDate:          f.viaDate,
      viaResult:        f.viaResult,
      historyOfSti:     f.historyOfSti,
      stiDate:          f.stiDate,
      stiResult:        f.stiResult,
      riskCode:         f.riskCode,
      motherBabyBook:   f.motherBabyBook,
      lmp:              f.lmp,
      edd:              f.edd,
      planToDeliverAt:  f.planToDeliverAt,
      ageOfGestation:   f.ageOfGestation,
      accompanyingPerson: f.accompanyingPerson,
      seenByDentist:    f.seenByDentist,
      dentistDate:      f.dentistDate,
      dentistVisits:    {
        first:  parseInt(f.dentistFirst) || 0,
        second: parseInt(f.dentistSecond) || 0,
        third:  parseInt(f.dentistThird) || 0,
      },
      seenByPhysician:  f.seenByPhysician,
      physicianDate:    f.physicianDate,
      physicianVisits:  {
        first:  parseInt(f.physicianFirst) || 0,
        second: parseInt(f.physicianSecond) || 0,
        third:  parseInt(f.physicianThird) || 0,
      },
      tt1: f.tt1, tt2: f.tt2, tt3: f.tt3, tt4: f.tt4, tt5: f.tt5,
      iodizedSalt:   f.iodizedSalt,
      ironSupplement: f.ironSupplement,
    };
  }

  // ── Save handler ───────────────────────────────────────────────────────────
  const handleSave = async () => {
    setSaving(true);
    setSaveError(null);

    try {
      if (activeTab === "ITR_6") {
        // ── ITR 6: Create new adult patient ──────────────────────────────────
        const payload = mapITR6ToPatient(itr6);
        const created = await patientsService.createPatient(payload);
        await addLogbookEntry({
          staffUsername: user.fullName,
          action:        "Add Record",
          patientName:   `${created.firstName} ${created.lastName}`,
          patientId:     created.id,
        });
        setItr6(blankITR6());

      } else if (activeTab === "ITR_5") {
        // ── ITR 5: Create new pediatric patient ──────────────────────────────
        const payload = mapITR5ToPatient(itr5);
        const created = await patientsService.createPatient(payload);
        await addLogbookEntry({
          staffUsername: user.fullName,
          action:        "Add Record",
          patientName:   `${created.firstName} ${created.lastName}`,
          patientId:     created.id,
        });
        setItr5(blankITR5());

      } else if (activeTab === "ITMR") {
        // ── ITMR: Attach maternal record to existing female patient ───────────
        const nameLower = itmr.patientName.toLowerCase().trim();
        const target = allPatients.find((p) => {
          const full = `${p.firstName} ${p.lastName}`.toLowerCase();
          return full === nameLower;
        });
        if (!target) {
          throw new Error(
            `Patient "${itmr.patientName}" not found in the system. ` +
            `Please select a valid female patient from the dropdown.`
          );
        }
        const maternalRecord = buildMaternalRecord(itmr);
        const updated: Patient = { ...target, maternalRecord, program: "Prenatal Care" };
        await patientsService.updatePatient(target.id, updated);
        await addLogbookEntry({
          staffUsername: user.fullName,
          action:        "Edit Record",
          patientName:   `${target.firstName} ${target.lastName}`,
          patientId:     target.id,
        });
        // Refresh the patient list so the dropdown stays current
        const fresh = await patientsService.getPatients();
        setAllPatients(fresh);
        setItmr(blankITMR());

      } else {
        // PCV tab — not yet fully implemented, mark saved visually
      }

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setSaveError(
        err instanceof Error
          ? err.message
          : "Failed to save the record. Please try again."
      );
    } finally {
      setSaving(false);
    }
  };

  const s6 = <K extends keyof ITR6Form>(k: K, v: ITR6Form[K]) => { setItr6((p) => ({ ...p, [k]: v })); setSaved(false); };
  const s5 = <K extends keyof ITR5Form>(k: K, v: ITR5Form[K]) => { setItr5((p) => ({ ...p, [k]: v })); setSaved(false); };
  const sm = <K extends keyof ITMRForm>(k: K, v: ITMRForm[K]) => { setItmr((p) => ({ ...p, [k]: v })); setSaved(false); };

  const pe6 = <K extends keyof PhysicalExamForm>(k: K, v: PhysicalExamForm[K]) =>
    setItr6((p) => ({ ...p, physicalExam: { ...p.physicalExam, [k]: v } }));
  const pe5 = <K extends keyof PhysicalExamForm>(k: K, v: PhysicalExamForm[K]) =>
    setItr5((p) => ({ ...p, physicalExam: { ...p.physicalExam, [k]: v } }));

  const toggleFH6 = (c: string) =>
    s6("familyHistory", itr6.familyHistory.includes(c) ? itr6.familyHistory.filter((x) => x !== c) : [...itr6.familyHistory, c]);
  const toggleFH5 = (c: string) =>
    s5("familyHistory", itr5.familyHistory.includes(c) ? itr5.familyHistory.filter((x) => x !== c) : [...itr5.familyHistory, c]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="flex flex-col h-full bg-white rounded-2xl shadow-lg overflow-hidden"
      style={{ fontFamily: "'Poppins', sans-serif" }}
    >
      {/* Sub-tabs */}
      <div className="flex border-b border-gray-200 bg-white px-4 pt-4 gap-2 overflow-x-auto">
        {tabs.map((tab, i) => (
          <motion.button
            key={tab.key}
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.28 }}
            onClick={() => { setActiveTab(tab.key); setSaveError(null); setSaved(false); }}
            className={`text-[10px] font-bold pb-3 border-b-2 transition-colors whitespace-nowrap px-2 ${
              activeTab === tab.key
                ? "border-[#004b96] text-[#004b96]"
                : "border-transparent text-gray-400 hover:text-[#004b96]"
            }`}
          >
            {tab.label}
          </motion.button>
        ))}
      </div>

      {/* Form area */}
      <div className="flex-1 overflow-y-auto p-5">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
          >

        {/* ══ ITR 6 — 6 Years Old and Above ══════════════════════════════════ */}
        {activeTab === "ITR_6" && (
          <>
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="text-center mb-5"
            >
              <h2 className="font-bold text-[#013155] text-xl">PATIENT REGISTRATION</h2>
              <p className="text-[#013155] text-xs mt-1">INDIVIDUAL TREATMENT RECORD FOR 6 YEARS OLD AND ABOVE</p>
            </motion.div>

            {/* Identifying Data */}
            <SectionBox title="Identifying Data" delay={0.05}>
              <div className="grid grid-cols-3 gap-4 mb-3">
                <div><label className={LC}>Last Name:</label><input className={IC} value={itr6.lastName} onChange={(e) => s6("lastName", e.target.value)} placeholder="del Rosario" /></div>
                <div><label className={LC}>First Name:</label><input className={IC} value={itr6.firstName} onChange={(e) => s6("firstName", e.target.value)} placeholder="Juan" /></div>
                <div><label className={LC}>M.I.:</label><input className={IC} value={itr6.mi} onChange={(e) => s6("mi", e.target.value)} placeholder="A" maxLength={3} /></div>
              </div>
              <div className="grid grid-cols-4 gap-4 mb-3">
                <div><label className={LC}>Age — Years:</label><input className={IC} type="number" min={0} value={itr6.ageYears} onChange={(e) => s6("ageYears", e.target.value)} placeholder="25" /></div>
                <div><label className={LC}>Age — Months:</label><input className={IC} type="number" min={0} max={11} value={itr6.ageMonths} onChange={(e) => s6("ageMonths", e.target.value)} placeholder="0" /></div>
                <div>
                  <label className={LC}>Sex:</label>
                  <div className="flex gap-4 mt-1">
                    {["Male","Female"].map((s) => (
                      <label key={s} className="flex items-center gap-1 cursor-pointer text-xs">
                        <div onClick={() => s6("sex", s)} className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${itr6.sex === s ? "border-[#004b96] bg-[#004b96]" : "border-gray-400"}`}>
                          {itr6.sex === s && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                        </div>
                        {s}
                      </label>
                    ))}
                  </div>
                </div>
                <div><label className={LC}>Birthday:</label><input className={IC} type="date" value={itr6.birthday} onChange={(e) => s6("birthday", e.target.value)} /></div>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-3">
                <div><label className={LC}>Religion:</label><input className={IC} value={itr6.religion} onChange={(e) => s6("religion", e.target.value)} placeholder="Roman Catholic" /></div>
                <div><label className={LC}>Barangay:</label><input className={IC} value={itr6.barangay} onChange={(e) => s6("barangay", e.target.value)} placeholder="Gov. Paciano Bangoy" /></div>
                <div><label className={LC}>City:</label><input className={IC} value={itr6.city} onChange={(e) => s6("city", e.target.value)} placeholder="Davao City" /></div>
              </div>
              <div><label className={LC}>Address:</label><input className={IC} value={itr6.address} onChange={(e) => s6("address", e.target.value)} placeholder="Blk 5 Lot 3 Phase 1" /></div>
            </SectionBox>

            {/* Past Medical History */}
            <SectionBox title="Past Medical History" delay={0.1}>
              <CoMorbSection data={itr6.coMorb} onChange={(d) => s6("coMorb", d)} isAdult={true} />
              <div className="mt-3">
                <label className={LC}>Maintenance Medication, Dose &amp; Frequency:</label>
                <textarea className={`${IC} resize-none`} rows={2} value={itr6.maintenanceMed} onChange={(e) => s6("maintenanceMed", e.target.value)} placeholder="e.g. Metformin 500mg twice daily" />
              </div>
              <div className="mt-2">
                <label className={LC}>Previous Illness / Surgeries:</label>
                <textarea className={`${IC} resize-none`} rows={2} value={itr6.previousIllnesses} onChange={(e) => s6("previousIllnesses", e.target.value)} placeholder="e.g. Chickenpox (2005)" />
              </div>
            </SectionBox>

            {/* Family History */}
            <SectionBox title="Family History" delay={0.15}>
              <FamilyHistorySection
                selected={itr6.familyHistory}
                other={itr6.familyHistoryOther}
                onToggle={toggleFH6}
                onOtherChange={(v) => s6("familyHistoryOther", v)}
              />
            </SectionBox>

            {/* Personal / Social History */}
            <SectionBox title="Personal / Social History" delay={0.2}>
              <div className="space-y-0.5">
                <YesNoRow label="Eats Healthy Diet" value={itr6.eatsHealthy} onChange={(v) => s6("eatsHealthy", v)} />
                <YesNoRow label="Adequate Physical Activity" value={itr6.adequateActivity} onChange={(v) => s6("adequateActivity", v)} />
                <YesNoRow label="Sufficient Rest / Sleep" value={itr6.sufficientRest} onChange={(v) => s6("sufficientRest", v)} />
                <YesNoRow label="Normal Growth and Development" value={itr6.normalGrowth} onChange={(v) => s6("normalGrowth", v)} />
                <YesNoRow label="Engage with Multiple Sex Partners" value={itr6.multiplePartners} onChange={(v) => s6("multiplePartners", v)} />
                <YesNoRow label="Smokes Tobacco" value={itr6.smokesTobacco} onChange={(v) => s6("smokesTobacco", v)} />
                {itr6.smokesTobacco && (
                  <div className="ml-4 pb-1"><label className={LC}>Pack per Year:</label>
                    <input className={`${IC} w-32`} type="number" min={0} value={itr6.tobaccoPacks} onChange={(e) => s6("tobaccoPacks", e.target.value)} />
                  </div>
                )}
                <YesNoRow label="Drinks Alcohol" value={itr6.drinksAlcohol} onChange={(v) => s6("drinksAlcohol", v)} />
                {itr6.drinksAlcohol && (
                  <div className="ml-4 pb-1"><label className={LC}>Bottle per Year:</label>
                    <input className={`${IC} w-32`} type="number" min={0} value={itr6.alcoholBottles} onChange={(e) => s6("alcoholBottles", e.target.value)} />
                  </div>
                )}
                <YesNoRow label="Takes Illegal Drugs" value={itr6.illegalDrugs} onChange={(v) => s6("illegalDrugs", v)} />
                {itr6.illegalDrugs && (
                  <div className="ml-4 pb-1"><label className={LC}>Specify:</label>
                    <input className={IC} value={itr6.illegalDrugsSpecify} onChange={(e) => s6("illegalDrugsSpecify", e.target.value)} placeholder="e.g. Methamphetamine" />
                  </div>
                )}
              </div>
            </SectionBox>

            {/* Physical Exam */}
            <SectionBox title="Physical Examination" delay={0.25}>
              <ExamSystemField title="SHEENT" data={itr6.physicalExam.sheent} options={SHEENT_OPTIONS} onChange={(d) => pe6("sheent", d)} />
              <ExamSystemField title="Chest, Breast & Lungs" data={itr6.physicalExam.chest} options={CHEST_OPTIONS} onChange={(d) => pe6("chest", d)} />
              <ExamSystemField title="Heart" data={itr6.physicalExam.heart} options={HEART_OPTIONS} onChange={(d) => pe6("heart", d)} />
              <ExamSystemField title="Abdomen" data={itr6.physicalExam.abdomen} options={ABDOMEN_OPTIONS} onChange={(d) => pe6("abdomen", d)} />
              <ExamSystemField title="Genitourinary" data={itr6.physicalExam.genitourinary} options={GU_OPTIONS} onChange={(d) => pe6("genitourinary", d)} />
              <ExamSystemField title="Extremities" data={itr6.physicalExam.extremities} options={EXTREMITIES_OPTIONS} onChange={(d) => pe6("extremities", d)} />
              <ExamSystemField title="Neurological" data={itr6.physicalExam.neurological} options={NEURO_OPTIONS} onChange={(d) => pe6("neurological", d)} />
            </SectionBox>

            <SaveBar agreed={itr6.agreedToTerms} onAgree={() => s6("agreedToTerms", !itr6.agreedToTerms)} onSave={handleSave} saved={saved} saving={saving} error={saveError} />
          </>
        )}

        {/* ══ ITR 5 — 5 Years Old and Below ══════════════════════════════════ */}
        {activeTab === "ITR_5" && (
          <>
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="text-center mb-5"
            >
              <h2 className="font-bold text-[#013155] text-xl">PATIENT REGISTRATION</h2>
              <p className="text-[#013155] text-xs mt-1">INDIVIDUAL TREATMENT RECORD FOR 5 YEARS OLD AND BELOW</p>
            </motion.div>

            {/* Identifying Data */}
            <SectionBox title="Identifying Data" delay={0.05}>
              <div className="grid grid-cols-3 gap-4 mb-3">
                <div><label className={LC}>Last Name:</label><input className={IC} value={itr5.lastName} onChange={(e) => s5("lastName", e.target.value)} placeholder="del Rosario" /></div>
                <div><label className={LC}>First Name:</label><input className={IC} value={itr5.firstName} onChange={(e) => s5("firstName", e.target.value)} placeholder="Juan" /></div>
                <div><label className={LC}>M.I.:</label><input className={IC} value={itr5.mi} onChange={(e) => s5("mi", e.target.value)} placeholder="A" maxLength={3} /></div>
              </div>
              <div className="grid grid-cols-4 gap-4 mb-3">
                <div><label className={LC}>Age — Years:</label><input className={IC} type="number" min={0} value={itr5.ageYears} onChange={(e) => s5("ageYears", e.target.value)} placeholder="3" /></div>
                <div><label className={LC}>Age — Months:</label><input className={IC} type="number" min={0} max={11} value={itr5.ageMonths} onChange={(e) => s5("ageMonths", e.target.value)} placeholder="6" /></div>
                <div>
                  <label className={LC}>Sex:</label>
                  <div className="flex gap-4 mt-1">
                    {["Male","Female"].map((s) => (
                      <label key={s} className="flex items-center gap-1 cursor-pointer text-xs">
                        <div onClick={() => s5("sex", s)} className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${itr5.sex === s ? "border-[#004b96] bg-[#004b96]" : "border-gray-400"}`}>
                          {itr5.sex === s && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                        </div>
                        {s}
                      </label>
                    ))}
                  </div>
                </div>
                <div><label className={LC}>Birthday:</label><input className={IC} type="date" value={itr5.birthday} onChange={(e) => s5("birthday", e.target.value)} /></div>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-3">
                <div><label className={LC}>Religion:</label><input className={IC} value={itr5.religion} onChange={(e) => s5("religion", e.target.value)} placeholder="Roman Catholic" /></div>
                <div><label className={LC}>Barangay:</label><input className={IC} value={itr5.barangay} onChange={(e) => s5("barangay", e.target.value)} placeholder="Gov. Paciano Bangoy" /></div>
                <div><label className={LC}>City:</label><input className={IC} value={itr5.city} onChange={(e) => s5("city", e.target.value)} placeholder="Davao City" /></div>
              </div>
              <div><label className={LC}>Address:</label><input className={IC} value={itr5.address} onChange={(e) => s5("address", e.target.value)} placeholder="Blk 5 Lot 3 Phase 1" /></div>
            </SectionBox>

            {/* Past Medical History */}
            <SectionBox title="Past Medical History" delay={0.1}>
              <CoMorbSection data={itr5.coMorb} onChange={(d) => s5("coMorb", d)} />
              <div className="mt-3">
                <label className={LC}>Maintenance Medication, Dose &amp; Frequency:</label>
                <textarea className={`${IC} resize-none`} rows={2} value={itr5.maintenanceMed} onChange={(e) => s5("maintenanceMed", e.target.value)} placeholder="e.g. Salbutamol 2mg as needed" />
              </div>
              <div className="mt-2">
                <label className={LC}>Previous Illness / Surgeries:</label>
                <textarea className={`${IC} resize-none`} rows={2} value={itr5.previousIllnesses} onChange={(e) => s5("previousIllnesses", e.target.value)} placeholder="e.g. Pneumonia (2023)" />
              </div>
            </SectionBox>

            {/* Newborn Care */}
            <SectionBox title="Newborn Care" delay={0.15}>
              <div className="grid grid-cols-3 gap-4 mb-3">
                <div>
                  <label className={LC}>Type of Delivery:</label>
                  <select className="w-full border-b border-gray-400 bg-transparent text-sm focus:outline-none focus:border-[#004b96] py-0.5" value={itr5.typeOfDelivery} onChange={(e) => s5("typeOfDelivery", e.target.value)}>
                    <option value="">Select</option>
                    <option value="Normal">Normal</option>
                    <option value="Caesarean Section">Caesarean Section</option>
                  </select>
                </div>
                <div><label className={LC}>Birth Weight:</label><input className={IC} value={itr5.birthWeight} onChange={(e) => s5("birthWeight", e.target.value)} placeholder="e.g. 3.2 kg" /></div>
                <div><label className={LC}>Birth Height:</label><input className={IC} value={itr5.birthHeight} onChange={(e) => s5("birthHeight", e.target.value)} placeholder="e.g. 50 cm" /></div>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div><label className={LC}>Current Weight:</label><input className={IC} value={itr5.currentWeight} onChange={(e) => s5("currentWeight", e.target.value)} placeholder="e.g. 15 kg" /></div>
                <div><label className={LC}>Current Height:</label><input className={IC} value={itr5.currentHeight} onChange={(e) => s5("currentHeight", e.target.value)} placeholder="e.g. 95 cm" /></div>
              </div>
              {/* Vaccines YES/NO + date */}
              {(["bcgVaccine","hepBVaccine","vitaminK"] as const).map((key) => {
                const labelMap = { bcgVaccine: "BCG Vaccine", hepBVaccine: "Hep B Vaccine", vitaminK: "Vitamin K" };
                const dateKey = { bcgVaccine: "bcgDate" as const, hepBVaccine: "hepBDate" as const, vitaminK: "vitaminKDate" as const }[key];
                const val = itr5[key] as boolean;
                return (
                  <div key={key} className="mb-2">
                    <YesNoRow label={labelMap[key]} value={val} onChange={(v) => s5(key, v)} />
                    {val && (
                      <div className="ml-4 mt-1"><label className={LC}>Date:</label>
                        <input className={IC} type="date" value={itr5[dateKey]} onChange={(e) => s5(dateKey, e.target.value)} />
                      </div>
                    )}
                  </div>
                );
              })}
              <div className="mb-2">
                <label className={LC}>Mother Tetanus Toxoid Status (# of Shots):</label>
                <select className="w-full border-b border-gray-400 bg-transparent text-sm focus:outline-none focus:border-[#004b96] py-0.5 mt-0.5" value={itr5.motherTetanusShots} onChange={(e) => s5("motherTetanusShots", e.target.value)}>
                  <option value="">Select</option>
                  {["1","2","3","4"].map((n) => <option key={n} value={n}>{n} Shot{n !== "1" ? "s" : ""}</option>)}
                </select>
              </div>
              <div className="mb-2">
                <YesNoRow label="Newborn Screening" value={itr5.newbornScreening} onChange={(v) => s5("newbornScreening", v)} />
                {itr5.newbornScreening && (
                  <div className="ml-4 mt-1 grid grid-cols-2 gap-3">
                    <div><label className={LC}>Date:</label><input className={IC} type="date" value={itr5.screeningDate} onChange={(e) => s5("screeningDate", e.target.value)} /></div>
                    <div><label className={LC}>Results:</label><input className={IC} value={itr5.screeningResults} onChange={(e) => s5("screeningResults", e.target.value)} placeholder="e.g. Normal" /></div>
                  </div>
                )}
              </div>
              <div className="mb-2">
                <YesNoRow label="Initiated Breastfeeding" value={itr5.initiatedBreastfeeding} onChange={(v) => s5("initiatedBreastfeeding", v)} />
                {itr5.initiatedBreastfeeding && (
                  <div className="ml-4 mt-1"><label className={LC}>Date:</label>
                    <input className={IC} type="date" value={itr5.breastfeedingDate} onChange={(e) => s5("breastfeedingDate", e.target.value)} />
                  </div>
                )}
              </div>
              <div>
                <label className={LC}>Place of Delivery:</label>
                <select className="w-full border-b border-gray-400 bg-transparent text-sm focus:outline-none focus:border-[#004b96] py-0.5 mt-0.5" value={itr5.placeOfDelivery} onChange={(e) => s5("placeOfDelivery", e.target.value)}>
                  <option value="">Select</option>
                  <option value="Hospital">Hospital</option>
                  <option value="Birthing Facility">Birthing Facility</option>
                  <option value="Home">Home</option>
                </select>
              </div>
            </SectionBox>

            {/* Family History */}
            <SectionBox title="Family History" delay={0.2}>
              <FamilyHistorySection
                selected={itr5.familyHistory}
                other={itr5.familyHistoryOther}
                onToggle={toggleFH5}
                onOtherChange={(v) => s5("familyHistoryOther", v)}
              />
            </SectionBox>

            {/* Personal / Social History (child) */}
            <SectionBox title="Personal / Social History" delay={0.25}>
              <div className="space-y-0.5">
                <YesNoRow label="Lives with Immediate Family" value={itr5.livesWithFamily} onChange={(v) => s5("livesWithFamily", v)} />
                <YesNoRow label="Uneventful Birth and Infancy" value={itr5.uneventfulBirth} onChange={(v) => s5("uneventfulBirth", v)} />
                <YesNoRow label="Normal Growth and Development" value={itr5.normalGrowth} onChange={(v) => s5("normalGrowth", v)} />
                <YesNoRow label="Normal Moods and Attitudes" value={itr5.normalMoods} onChange={(v) => s5("normalMoods", v)} />
                <YesNoRow label="Normal Interest in Family and Friends" value={itr5.normalInterestFamily} onChange={(v) => s5("normalInterestFamily", v)} />
                <YesNoRow label="Normal Interest in Work and Play" value={itr5.normalInterestWork} onChange={(v) => s5("normalInterestWork", v)} />
                <YesNoRow label="Adequate Physical Activity" value={itr5.adequateActivity} onChange={(v) => s5("adequateActivity", v)} />
                <YesNoRow label="Sufficient Rest / Sleep" value={itr5.sufficientRest} onChange={(v) => s5("sufficientRest", v)} />
              </div>
              <div className="mt-2">
                <label className={LC}>Others, Specify:</label>
                <input className={IC} value={itr5.socialOther} onChange={(e) => s5("socialOther", e.target.value)} placeholder="Additional notes…" />
              </div>
            </SectionBox>

            {/* Physical Exam */}
            <SectionBox title="Physical Examination" delay={0.3}>
              <ExamSystemField title="SHEENT" data={itr5.physicalExam.sheent} options={SHEENT_OPTIONS} onChange={(d) => pe5("sheent", d)} />
              <ExamSystemField title="Chest, Breast & Lungs" data={itr5.physicalExam.chest} options={CHEST_OPTIONS} onChange={(d) => pe5("chest", d)} />
              <ExamSystemField title="Heart" data={itr5.physicalExam.heart} options={HEART_OPTIONS} onChange={(d) => pe5("heart", d)} />
              <ExamSystemField title="Abdomen" data={itr5.physicalExam.abdomen} options={ABDOMEN_OPTIONS} onChange={(d) => pe5("abdomen", d)} />
              <ExamSystemField title="Genitourinary" data={itr5.physicalExam.genitourinary} options={GU_OPTIONS} onChange={(d) => pe5("genitourinary", d)} />
              <ExamSystemField title="Extremities" data={itr5.physicalExam.extremities} options={EXTREMITIES_OPTIONS} onChange={(d) => pe5("extremities", d)} />
              <ExamSystemField title="Neurological" data={itr5.physicalExam.neurological} options={NEURO_OPTIONS} onChange={(d) => pe5("neurological", d)} />
            </SectionBox>

            <SaveBar agreed={itr5.agreedToTerms} onAgree={() => s5("agreedToTerms", !itr5.agreedToTerms)} onSave={handleSave} saved={saved} saving={saving} error={saveError} />
          </>
        )}

        {/* ══ ITMR — Maternal Registration ═══════════════════════════════════ */}
        {activeTab === "ITMR" && (
          <>
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="text-center mb-5"
            >
              <h2 className="font-bold text-[#013155] text-xl">MATERNAL REGISTRATION</h2>
              <p className="text-[#013155] text-xs mt-1">INDIVIDUAL TREATMENT MATERNAL RECORD</p>
            </motion.div>

            {/* Name */}
            <SectionBox title="Patient" delay={0.05}>
              <PatientNameDropdown value={itmr.patientName} onChange={(v) => sm("patientName", v)} patients={allPatients} />
            </SectionBox>

            {/* OB Score */}
            <SectionBox title="OB Score" delay={0.1}>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                {([["g","G"],["p","P"],["fullTerm","Full Term"],["preterm","Preterm"],["abortion","Abortion"],["living","Living"]] as const).map(([key, label]) => (
                  <div key={key} className="bg-[#e8f4fd] rounded-xl p-2 text-center">
                    <p className="text-[10px] text-gray-500 font-semibold mb-1">{label}</p>
                    <input type="number" min={0} value={itmr[key]} onChange={(e) => sm(key, e.target.value)}
                      className="w-full text-center text-[#004b96] font-bold bg-transparent border-b border-[#004b96]/30 focus:outline-none focus:border-[#004b96] text-lg" />
                  </div>
                ))}
              </div>
            </SectionBox>

            {/* Gynecological History */}
            <SectionBox title="Gynecological History" delay={0.15}>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-3">
                <div><label className={LC}>Menarche Age:</label><input className={IC} type="number" min={0} value={itmr.menarcheAge} onChange={(e) => sm("menarcheAge", e.target.value)} placeholder="13" /></div>
                <div>
                  <label className={LC}>Menstrual Cycle:</label>
                  <select className="w-full border-b border-gray-400 bg-transparent text-sm focus:outline-none focus:border-[#004b96] py-0.5 mt-0.5" value={itmr.menstrualCycle} onChange={(e) => sm("menstrualCycle", e.target.value)}>
                    <option value="Regular">Regular</option>
                    <option value="Irregular">Irregular</option>
                  </select>
                </div>
                <div><label className={LC}>Menstrual Flow (days):</label><input className={IC} type="number" min={0} value={itmr.menstrualFlowDays} onChange={(e) => sm("menstrualFlowDays", e.target.value)} placeholder="5" /></div>
                <div><label className={LC}>Coitarche Age:</label><input className={IC} type="number" min={0} value={itmr.coitarcheAge} onChange={(e) => sm("coitarcheAge", e.target.value)} placeholder="22" /></div>
                <div className="sm:col-span-2"><label className={LC}>Current FP Method:</label><input className={IC} value={itmr.currentFpMethod} onChange={(e) => sm("currentFpMethod", e.target.value)} placeholder="e.g. Oral Contraceptive Pills" /></div>
              </div>
              {/* PAP Smear / VIA / STI */}
              <div className="space-y-3 mt-2">
                {([
                  { key: "papSmear" as const, dateKey: "papSmearDate" as const, resultKey: "papSmearResult" as const, label: "PAP Smear" },
                  { key: "via" as const, dateKey: "viaDate" as const, resultKey: "viaResult" as const, label: "VIA" },
                  { key: "historyOfSti" as const, dateKey: "stiDate" as const, resultKey: "stiResult" as const, label: "History of STI" },
                ]).map(({ key, dateKey, resultKey, label }) => (
                  <div key={key} className="border border-gray-200 rounded-lg p-3">
                    <YesNoRow label={label} value={itmr[key]} onChange={(v) => sm(key, v)} />
                    {itmr[key] && (
                      <div className="grid grid-cols-2 gap-3 mt-2 ml-2">
                        <div><label className={LC}>Date:</label><input className={IC} value={itmr[dateKey]} onChange={(e) => sm(dateKey, e.target.value)} placeholder="e.g. January 10, 2025" /></div>
                        <div><label className={LC}>Result:</label><input className={IC} value={itmr[resultKey]} onChange={(e) => sm(resultKey, e.target.value)} placeholder="e.g. Normal / Negative" /></div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </SectionBox>

            {/* Prenatal Care */}
            <SectionBox title="Prenatal Care — Details of Present Pregnancy" delay={0.2}>
              <div className="grid grid-cols-2 gap-4 mb-3">
                <div><label className={LC}>Risk Code:</label><input className={IC} value={itmr.riskCode} onChange={(e) => sm("riskCode", e.target.value)} placeholder="e.g. Low Risk" /></div>
                <div><label className={LC}>Age of Gestation:</label><input className={IC} value={itmr.ageOfGestation} onChange={(e) => sm("ageOfGestation", e.target.value)} placeholder="e.g. 12 weeks" /></div>
                <div><label className={LC}>Last Menstrual Period:</label><input className={IC} value={itmr.lmp} onChange={(e) => sm("lmp", e.target.value)} placeholder="e.g. November 20, 2025" /></div>
                <div><label className={LC}>Expected Date of Delivery:</label><input className={IC} value={itmr.edd} onChange={(e) => sm("edd", e.target.value)} placeholder="e.g. August 27, 2026" /></div>
                <div><label className={LC}>Plan to Deliver At:</label><input className={IC} value={itmr.planToDeliverAt} onChange={(e) => sm("planToDeliverAt", e.target.value)} placeholder="e.g. Davao Medical Center" /></div>
                <div><label className={LC}>Accompanying Person:</label><input className={IC} value={itmr.accompanyingPerson} onChange={(e) => sm("accompanyingPerson", e.target.value)} placeholder="Name of companion" /></div>
              </div>
              <YesNoRow label="Mother-Baby Book" value={itmr.motherBabyBook} onChange={(v) => sm("motherBabyBook", v)} />
            </SectionBox>

            {/* Provider Visits */}
            <SectionBox title="Provider Visits" delay={0.25}>
              {/* Dentist */}
              <div className="border border-gray-200 rounded-lg p-3 mb-3">
                <YesNoRow label="Seen by Dentist" value={itmr.seenByDentist} onChange={(v) => sm("seenByDentist", v)} />
                {itmr.seenByDentist && (
                  <div className="mt-2 ml-2 space-y-2">
                    <div><label className={LC}>Date:</label><input className={IC} value={itmr.dentistDate} onChange={(e) => sm("dentistDate", e.target.value)} placeholder="e.g. December 5, 2025" /></div>
                    <div className="grid grid-cols-3 gap-3">
                      <div><label className={LC}>1st Trimester Visits:</label><input className={IC} type="number" min={0} value={itmr.dentistFirst} onChange={(e) => sm("dentistFirst", e.target.value)} /></div>
                      <div><label className={LC}>2nd Trimester Visits:</label><input className={IC} type="number" min={0} value={itmr.dentistSecond} onChange={(e) => sm("dentistSecond", e.target.value)} /></div>
                      <div><label className={LC}>3rd Trimester Visits:</label><input className={IC} type="number" min={0} value={itmr.dentistThird} onChange={(e) => sm("dentistThird", e.target.value)} /></div>
                    </div>
                  </div>
                )}
              </div>
              {/* Physician */}
              <div className="border border-gray-200 rounded-lg p-3">
                <YesNoRow label="Seen by Physician" value={itmr.seenByPhysician} onChange={(v) => sm("seenByPhysician", v)} />
                {itmr.seenByPhysician && (
                  <div className="mt-2 ml-2 space-y-2">
                    <div><label className={LC}>Date:</label><input className={IC} value={itmr.physicianDate} onChange={(e) => sm("physicianDate", e.target.value)} placeholder="e.g. February 14, 2026" /></div>
                    <div className="grid grid-cols-3 gap-3">
                      <div><label className={LC}>1st Trimester Visits:</label><input className={IC} type="number" min={0} value={itmr.physicianFirst} onChange={(e) => sm("physicianFirst", e.target.value)} /></div>
                      <div><label className={LC}>2nd Trimester Visits:</label><input className={IC} type="number" min={0} value={itmr.physicianSecond} onChange={(e) => sm("physicianSecond", e.target.value)} /></div>
                      <div><label className={LC}>3rd Trimester Visits:</label><input className={IC} type="number" min={0} value={itmr.physicianThird} onChange={(e) => sm("physicianThird", e.target.value)} /></div>
                    </div>
                  </div>
                )}
              </div>
            </SectionBox>

            {/* Tetanus Toxoid */}
            <SectionBox title="Tetanus Toxoid Status and Date" delay={0.3}>
              <div className="grid grid-cols-5 gap-2">
                {(["tt1","tt2","tt3","tt4","tt5"] as const).map((key, i) => {
                  const { month, year } = parseTTReg(itmr[key]);
                  return (
                    <div key={key} className="bg-[#e8f4fd] rounded-xl p-2 text-center">
                      <p className="text-[#004b96] font-bold text-xs mb-1">TT{i + 1}</p>
                      <select
                        className="w-full text-center text-[10px] bg-white border border-[#004b96]/30 rounded focus:outline-none focus:border-[#004b96] text-gray-700 mb-1 py-0.5"
                        value={month}
                        onChange={(e) => sm(key, formatTTReg(e.target.value, year))}
                      >
                        <option value="">Month</option>
                        {MONTHS_REG.map((m) => <option key={m} value={m}>{m.slice(0, 3)}</option>)}
                      </select>
                      <select
                        className="w-full text-center text-[10px] bg-white border border-[#004b96]/30 rounded focus:outline-none focus:border-[#004b96] text-gray-700 py-0.5"
                        value={year}
                        onChange={(e) => sm(key, formatTTReg(month, e.target.value))}
                      >
                        <option value="">Year</option>
                        {TT_YEARS_REG.map((y) => <option key={y} value={y}>{y}</option>)}
                      </select>
                    </div>
                  );
                })}
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <YesNoRow label="Iodized Salt" value={itmr.iodizedSalt} onChange={(v) => sm("iodizedSalt", v)} />
                <YesNoRow label="Iron Supplement" value={itmr.ironSupplement} onChange={(v) => sm("ironSupplement", v)} />
              </div>
            </SectionBox>

            <SaveBar agreed={itmr.agreedToTerms} onAgree={() => sm("agreedToTerms", !itmr.agreedToTerms)} onSave={handleSave} saved={saved} saving={saving} error={saveError} />
          </>
        )}

        {/* ══ PCV ═══════════════════════════════════════════════════════════ */}
        {activeTab === "PCV" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center justify-center h-full py-24 text-gray-400"
          >
            <p className="font-semibold text-base">PCV Record</p>
            <p className="text-sm mt-1">Coming soon</p>
          </motion.div>
        )}

          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}