import { useState, useEffect } from "react";
import { Filter, Pencil, ChevronLeft, ChevronRight, X, SlidersHorizontal } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import type { Patient, TriOption } from "./mockData";
import * as patientsService from "../../api/patients.service";
import { PatientMedicalProfile } from "./PatientMedicalProfile";
import { PatientEditModal } from "./PatientEditModal";

const ITEMS_PER_PAGE = 9;

const programs = ["All Program", "Prenatal Care", "Family Planning", "National Immunization", "National Tuberculosis", "Cardiovascular Disease"];
const puroks = ["All Purok", "Moordcano", "Karang", "Bible Biopstam'i", "Calcra'g", "Monahino/Karinw", "Dale1"];
const TRI_OPTIONS: { label: string; value: "" | TriOption }[] = [
  { label: "All", value: "" },
  { label: "YES", value: "YES" },
  { label: "NO", value: "NO" },
  { label: "DON'T APPLY", value: "N/A" },
];
const FAMILY_HISTORY_LIST = [
  "Asthma/Allergies",
  "Birth Defects",
  "Cancer",
  "Dementia",
  "Diabetes",
  "Hypertension",
  "Lung Disease",
  "Mental Illness",
];

interface AdvancedFilters {
  middleInitial: string;
  ageYearsMin: string;
  ageYearsMax: string;
  ageMonthsMin: string;
  ageMonthsMax: string;
  sex: "" | "Male" | "Female";
  birthday: string;
  religion: string;
  barangay: string;
  city: string;
  weightMin: string;
  weightMax: string;
  heightMin: string;
  heightMax: string;
  bcgVaccine: "" | TriOption;
  hepBVaccine: "" | TriOption;
  vitaminK: "" | TriOption;
  vitamins: boolean;
  familyHistoryConditions: string[];
  familyHistoryOther: string;
  familyHistoryMother: "" | TriOption;
}

const DEFAULT_FILTERS: AdvancedFilters = {
  middleInitial: "",
  ageYearsMin: "",
  ageYearsMax: "",
  ageMonthsMin: "",
  ageMonthsMax: "",
  sex: "",
  birthday: "",
  religion: "",
  barangay: "",
  city: "",
  weightMin: "",
  weightMax: "",
  heightMin: "",
  heightMax: "",
  bcgVaccine: "",
  hepBVaccine: "",
  vitaminK: "",
  vitamins: false,
  familyHistoryConditions: [],
  familyHistoryOther: "",
  familyHistoryMother: "",
};

function isFiltersActive(f: AdvancedFilters): boolean {
  return Object.entries(f).some(([, v]) => (Array.isArray(v) ? v.length > 0 : v !== "" && v !== false));
}

function parseKg(s: string) { return parseInt(s.replace(/[^0-9]/g, ""), 10) || 0; }
function parseCm(s: string) { return parseInt(s.replace(/[^0-9]/g, ""), 10) || 0; }

const inputCls = "border border-gray-300 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:border-[#004b96] focus:ring-1 focus:ring-[#004b96]/20 w-full";
const labelCls = "text-xs font-semibold text-gray-600 mb-1 block";
const sectionTitleCls = "text-[#004b96] font-bold text-xs uppercase tracking-wider mb-2.5 pb-1.5 border-b-2 border-[#004b96]/20 flex items-center gap-1.5";

function TriSelect({ label, value, onChange }: { label: string; value: string; onChange: (v: "" | TriOption) => void }) {
  return (
    <div>
      <label className={labelCls}>{label}</label>
      <div className="flex gap-1 flex-wrap">
        {TRI_OPTIONS.map((opt) => (
          <button
            key={opt.label}
            type="button"
            onClick={() => onChange(opt.value)}
            className={`px-2 py-1 rounded-md text-xs font-medium border transition-all ${
              value === opt.value
                ? "bg-[#004b96] text-white border-[#004b96]"
                : "bg-white text-gray-600 border-gray-300 hover:border-[#004b96] hover:text-[#004b96]"
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function PatientInformation() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading]   = useState(true);
  const [searchLast, setSearchLast]   = useState("");
  const [searchFirst, setSearchFirst] = useState("");
  const [selectedProgram, setSelectedProgram] = useState("All Program");
  const [selectedPurok, setSelectedPurok] = useState("All Purok");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [showAdvancedFilter, setShowAdvancedFilter] = useState(false);
  const [advFilters, setAdvFilters] = useState<AdvancedFilters>(DEFAULT_FILTERS);
  const [appliedAdvFilters, setAppliedAdvFilters] = useState<AdvancedFilters>(DEFAULT_FILTERS);

  // Load patients from service on mount
  useEffect(() => {
    patientsService
      .getPatients()
      .then(setPatients)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleSavePatient = (updated: Patient) => {
    patientsService.updatePatient(updated.id, updated).then((saved) => {
      setPatients((prev) => prev.map((p) => (p.id === saved.id ? saved : p)));
    });
  };

  const setAdv = <K extends keyof AdvancedFilters>(key: K, value: AdvancedFilters[K]) => {
    setAdvFilters((prev) => ({ ...prev, [key]: value }));
  };

  const toggleCondition = (cond: string) => {
    setAdvFilters((prev) => ({
      ...prev,
      familyHistoryConditions: prev.familyHistoryConditions.includes(cond)
        ? prev.familyHistoryConditions.filter((c) => c !== cond)
        : [...prev.familyHistoryConditions, cond],
    }));
  };

  const handleApply = () => {
    setAppliedAdvFilters({ ...advFilters });
    setCurrentPage(1);
  };

  const handleClear = () => {
    setAdvFilters(DEFAULT_FILTERS);
    setAppliedAdvFilters(DEFAULT_FILTERS);
    setCurrentPage(1);
  };

  const filtered = patients.filter((p) => {
    // Basic filters
    if (!p.lastName.toLowerCase().includes(searchLast.toLowerCase())) return false;
    if (!p.firstName.toLowerCase().includes(searchFirst.toLowerCase())) return false;
    if (selectedProgram !== "All Program" && p.program !== selectedProgram) return false;
    if (selectedPurok !== "All Purok" && p.purok !== selectedPurok) return false;

    // Advanced filters
    const af = appliedAdvFilters;
    if (af.middleInitial && !p.middleInitial.toLowerCase().includes(af.middleInitial.toLowerCase())) return false;
    if (af.sex && p.sex !== af.sex) return false;
    if (af.birthday && !p.birthday.toLowerCase().includes(af.birthday.toLowerCase())) return false;
    if (af.religion && !p.religion.toLowerCase().includes(af.religion.toLowerCase())) return false;
    if (af.barangay && !p.barangay.toLowerCase().includes(af.barangay.toLowerCase())) return false;
    if (af.city && !p.city.toLowerCase().includes(af.city.toLowerCase())) return false;
    if (af.vitamins && !p.vitamins) return false;

    // Age range
    if (af.ageYearsMin && p.age < parseInt(af.ageYearsMin)) return false;
    if (af.ageYearsMax && p.age > parseInt(af.ageYearsMax)) return false;
    if (af.ageMonthsMin && p.ageMonths < parseInt(af.ageMonthsMin)) return false;
    if (af.ageMonthsMax && p.ageMonths > parseInt(af.ageMonthsMax)) return false;

    // Weight / Height
    const w = parseKg(p.weight);
    const h = parseCm(p.height);
    if (af.weightMin && w < parseInt(af.weightMin)) return false;
    if (af.weightMax && w > parseInt(af.weightMax)) return false;
    if (af.heightMin && h < parseInt(af.heightMin)) return false;
    if (af.heightMax && h > parseInt(af.heightMax)) return false;

    // Vaccines
    if (af.bcgVaccine && p.bcgVaccine !== af.bcgVaccine) return false;
    if (af.hepBVaccine && p.hepBVaccine !== af.hepBVaccine) return false;
    if (af.vitaminK && p.vitaminK !== af.vitaminK) return false;

    // Family History conditions (patient must have ALL selected)
    if (af.familyHistoryConditions.length > 0) {
      if (!af.familyHistoryConditions.every((c) => p.familyHistoryConditions.includes(c))) return false;
    }
    if (af.familyHistoryOther && !p.familyHistoryOther.toLowerCase().includes(af.familyHistoryOther.toLowerCase())) return false;
    if (af.familyHistoryMother && p.familyHistoryMother !== af.familyHistoryMother) return false;

    return true;
  });

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);
  const filterActive = isFiltersActive(appliedAdvFilters);
  const pendingChanges = JSON.stringify(advFilters) !== JSON.stringify(appliedAdvFilters);

  return (
    <div className="flex flex-col gap-3 h-full" style={{ fontFamily: "'Poppins', sans-serif" }}>
      {/* Header */}
      <div>
        <h1 className="text-[#004b96] font-extrabold text-4xl leading-tight">DASHBOARD</h1>
        <p className="text-[#004b96] font-bold text-base">PATIENT INFORMATION:</p>
      </div>

      {/* Row 1: Name Search Fields */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <label className="font-bold text-sm text-black whitespace-nowrap">Last Name</label>
          <input
            type="text"
            placeholder="ex. Cruz"
            value={searchLast}
            onChange={(e) => { setSearchLast(e.target.value); setCurrentPage(1); }}
            className="border border-gray-400 rounded-lg px-3 py-1.5 text-sm bg-white w-32 focus:outline-none focus:border-[#004b96]"
          />
        </div>
        <div className="flex items-center gap-2">
          <label className="font-bold text-sm text-black whitespace-nowrap">First Name</label>
          <input
            type="text"
            placeholder="ex. John"
            value={searchFirst}
            onChange={(e) => { setSearchFirst(e.target.value); setCurrentPage(1); }}
            className="border border-gray-400 rounded-lg px-3 py-1.5 text-sm bg-white w-32 focus:outline-none focus:border-[#004b96]"
          />
        </div>
        <div className="flex items-center gap-2">
          <label className="font-bold text-sm text-black whitespace-nowrap">Middle Initial</label>
          <input
            type="text"
            placeholder="ex. B"
            maxLength={3}
            value={advFilters.middleInitial}
            onChange={(e) => { setAdv("middleInitial", e.target.value); setCurrentPage(1); }}
            className="border border-gray-400 rounded-lg px-3 py-1.5 text-sm bg-white w-20 focus:outline-none focus:border-[#004b96]"
          />
        </div>
      </div>

      {/* Row 2: Dropdowns */}
      <div className="flex flex-wrap items-center gap-3">
        <select
          value={selectedProgram}
          onChange={(e) => { setSelectedProgram(e.target.value); setCurrentPage(1); }}
          className="border border-gray-400 rounded-lg px-3 py-1.5 text-sm bg-white focus:outline-none focus:border-[#004b96] min-w-[160px]"
        >
          {programs.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
        <select
          value={selectedPurok}
          onChange={(e) => { setSelectedPurok(e.target.value); setCurrentPage(1); }}
          className="border border-gray-400 rounded-lg px-3 py-1.5 text-sm bg-white focus:outline-none focus:border-[#004b96] min-w-[140px]"
        >
          {puroks.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      {/* Advanced Filter Panel */}
      <AnimatePresence>
        {showAdvancedFilter && (
          <motion.div
            initial={{ opacity: 0, y: -12, scaleY: 0.95 }}
            animate={{ opacity: 1, y: 0, scaleY: 1 }}
            exit={{ opacity: 0, y: -12, scaleY: 0.95 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            style={{ transformOrigin: "top" }}
            className="bg-white border border-[#004b96]/30 rounded-xl shadow-lg overflow-hidden"
          >
            {/* Panel Header */}
            <div className="flex items-center justify-between px-5 py-3 bg-[#004b96]">
              <div className="flex items-center gap-2 text-white">
                <SlidersHorizontal size={15} />
                <span className="font-bold text-sm">Advanced Filters</span>
                {filterActive && (
                  <span className="bg-white/20 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAdvancedFilter(false)}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            <div className="p-4 space-y-5 max-h-[70vh] overflow-y-auto">
              {/* Section 1: Personal Information */}
              <div>
                <p className={sectionTitleCls}>Personal Information</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className={labelCls}>Sex</label>
                    <div className="flex flex-col gap-1 mt-1">
                      {(["", "Male", "Female"] as const).map((s) => (
                        <label key={s} className="flex items-center gap-1.5 cursor-pointer text-xs text-gray-700">
                          <input
                            type="radio"
                            name="adv-sex"
                            checked={advFilters.sex === s}
                            onChange={() => setAdv("sex", s)}
                            className="accent-[#004b96]"
                          />
                          {s === "" ? "All" : s}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className={labelCls}>Birthday</label>
                    <input
                      className={inputCls}
                      placeholder="e.g. March or 1998"
                      value={advFilters.birthday}
                      onChange={(e) => setAdv("birthday", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Demographics */}
              <div>
                <p className={sectionTitleCls}>Demographics</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  <div>
                    <label className={labelCls}>Age – Years</label>
                    <div className="flex items-center gap-1">
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Min"
                        min={0}
                        value={advFilters.ageYearsMin}
                        onChange={(e) => setAdv("ageYearsMin", e.target.value)}
                      />
                      <span className="text-gray-400 text-xs">–</span>
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Max"
                        min={0}
                        value={advFilters.ageYearsMax}
                        onChange={(e) => setAdv("ageYearsMax", e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className={labelCls}>Age – Months</label>
                    <div className="flex items-center gap-1">
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Min"
                        min={0}
                        max={11}
                        value={advFilters.ageMonthsMin}
                        onChange={(e) => setAdv("ageMonthsMin", e.target.value)}
                      />
                      <span className="text-gray-400 text-xs">–</span>
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Max"
                        min={0}
                        max={11}
                        value={advFilters.ageMonthsMax}
                        onChange={(e) => setAdv("ageMonthsMax", e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className={labelCls}>Religion</label>
                    <input
                      className={inputCls}
                      placeholder="e.g. Catholic"
                      value={advFilters.religion}
                      onChange={(e) => setAdv("religion", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className={labelCls}>Barangay</label>
                    <input
                      className={inputCls}
                      placeholder="e.g. Gov. Paciano"
                      value={advFilters.barangay}
                      onChange={(e) => setAdv("barangay", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className={labelCls}>City</label>
                    <input
                      className={inputCls}
                      placeholder="e.g. Davao City"
                      value={advFilters.city}
                      onChange={(e) => setAdv("city", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Physical Measurements */}
              <div>
                <p className={sectionTitleCls}>Physical Measurements</p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={labelCls}>Weight (kg) – Min to Max</label>
                    <div className="flex items-center gap-2">
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Min kg"
                        min={0}
                        value={advFilters.weightMin}
                        onChange={(e) => setAdv("weightMin", e.target.value)}
                      />
                      <span className="text-gray-400 text-xs font-semibold">–</span>
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Max kg"
                        min={0}
                        value={advFilters.weightMax}
                        onChange={(e) => setAdv("weightMax", e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className={labelCls}>Height (cm) – Min to Max</label>
                    <div className="flex items-center gap-2">
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Min cm"
                        min={0}
                        value={advFilters.heightMin}
                        onChange={(e) => setAdv("heightMin", e.target.value)}
                      />
                      <span className="text-gray-400 text-xs font-semibold">–</span>
                      <input
                        className={inputCls}
                        type="number"
                        placeholder="Max cm"
                        min={0}
                        value={advFilters.heightMax}
                        onChange={(e) => setAdv("heightMax", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 4: Vaccines */}
              <div>
                <p className={sectionTitleCls}>Vaccines</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <TriSelect
                    label="Take BCG Vaccine"
                    value={advFilters.bcgVaccine}
                    onChange={(v) => setAdv("bcgVaccine", v)}
                  />
                  <TriSelect
                    label="Take HEP B Vaccine"
                    value={advFilters.hepBVaccine}
                    onChange={(v) => setAdv("hepBVaccine", v)}
                  />
                  <TriSelect
                    label="Vitamin K"
                    value={advFilters.vitaminK}
                    onChange={(v) => setAdv("vitaminK", v)}
                  />
                </div>
                {/* Vitamins toggle */}
                <div className="mt-3">
                  <label className={`inline-flex items-center gap-2.5 cursor-pointer select-none px-4 py-2 rounded-lg border text-xs font-medium transition-all ${
                    advFilters.vitamins
                      ? "bg-[#004b96] text-white border-[#004b96]"
                      : "bg-white text-gray-600 border-gray-200 hover:border-[#004b96]/50 hover:text-[#004b96]"
                  }`}>
                    <input
                      type="checkbox"
                      checked={advFilters.vitamins}
                      onChange={(e) => setAdv("vitamins", e.target.checked)}
                      className="sr-only"
                    />
                    <span className={`w-3.5 h-3.5 rounded border flex-shrink-0 flex items-center justify-center ${advFilters.vitamins ? "bg-white border-white" : "border-gray-400"}`}>
                      {advFilters.vitamins && (
                        <svg viewBox="0 0 10 10" className="w-2.5 h-2.5 text-[#004b96]" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M1.5 5l2.5 2.5 4.5-4.5" />
                        </svg>
                      )}
                    </span>
                    With Vitamins only
                  </label>
                </div>
              </div>

              {/* Section 5: Family History */}
              <div>
                <p className={sectionTitleCls}>Family History</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                  {FAMILY_HISTORY_LIST.map((cond) => {
                    const isChecked = advFilters.familyHistoryConditions.includes(cond);
                    return (
                      <label
                        key={cond}
                        className={`flex items-center gap-2 cursor-pointer rounded-lg px-3 py-2 border text-xs font-medium transition-all ${
                          isChecked
                            ? "bg-[#004b96] text-white border-[#004b96]"
                            : "bg-white text-gray-600 border-gray-200 hover:border-[#004b96]/50 hover:text-[#004b96]"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleCondition(cond)}
                          className="sr-only"
                        />
                        <span className={`w-3.5 h-3.5 rounded border flex-shrink-0 flex items-center justify-center ${isChecked ? "bg-white border-white" : "border-gray-400"}`}>
                          {isChecked && (
                            <svg viewBox="0 0 10 10" className="w-2.5 h-2.5 text-[#004b96]" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M1.5 5l2.5 2.5 4.5-4.5" />
                            </svg>
                          )}
                        </span>
                        {cond}
                      </label>
                    );
                  })}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className={labelCls}>Other, Specify</label>
                    <input
                      className={inputCls}
                      placeholder="e.g. Heart disease"
                      value={advFilters.familyHistoryOther}
                      onChange={(e) => setAdv("familyHistoryOther", e.target.value)}
                    />
                  </div>
                  <TriSelect
                    label="Mother"
                    value={advFilters.familyHistoryMother}
                    onChange={(v) => setAdv("familyHistoryMother", v)}
                  />
                </div>
              </div>
            </div>

            {/* Panel Footer */}
            <div className="flex items-center justify-between px-5 py-3 bg-gray-50 border-t border-gray-200">
              <p className="text-xs text-gray-500">
                {filtered.length} patient{filtered.length !== 1 ? "s" : ""} match{filtered.length === 1 ? "es" : ""} current filters
              </p>
              <div className="flex gap-2">
                <button
                  onClick={handleClear}
                  className="px-4 py-1.5 text-sm border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors"
                >
                  Clear
                </button>
                <button
                  onClick={handleApply}
                  disabled={!pendingChanges}
                  className="px-5 py-1.5 text-sm bg-[#004b96] text-white rounded-lg hover:bg-[#003a75] transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Patient Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden flex-1">
        <div className="flex items-center justify-between px-5 py-3 bg-[#ddeef8] border-b border-gray-200">
          <p className="font-bold text-[#004b96] text-sm tracking-wide">PATIENT INFORMATION:</p>
          <button
            onClick={() => setShowAdvancedFilter((v) => !v)}
            className={`flex items-center gap-1.5 font-semibold text-sm transition-colors px-3 py-1 rounded-md ${
              filterActive
                ? "bg-[#004b96] text-white"
                : "text-[#004b96] hover:bg-[#004b96]/10"
            }`}
          >
            <Filter size={14} />
            FILTER
            {filterActive && (
              <span className="bg-white text-[#004b96] text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                ✓
              </span>
            )}
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#004b96] text-white">
                <th className="px-4 py-2.5 text-left font-semibold">Patient Name</th>
                <th className="px-4 py-2.5 text-left font-semibold">Age</th>
                <th className="px-4 py-2.5 text-left font-semibold">Spouse/Code</th>
                <th className="px-4 py-2.5 text-left font-semibold"># of<br/>Children</th>
                <th className="px-4 py-2.5 text-left font-semibold">Family<br/>Planning</th>
                <th className="px-4 py-2.5 text-left font-semibold">Purok</th>
                <th className="px-4 py-2.5 text-left font-semibold">Edit</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-gray-400">
                    <svg className="animate-spin w-5 h-5 mx-auto text-[#004b96]" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                    </svg>
                  </td>
                </tr>
              ) : paginated.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-gray-400">No patients found</td>
                </tr>
              ) : (
                paginated.map((patient, idx) => (
                  <motion.tr
                    key={patient.id}
                    initial={{ opacity: 0, x: -14 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05, duration: 0.25, ease: "easeOut" }}
                    whileHover={{ backgroundColor: "#ddeef8" }}
                    onClick={() => setSelectedPatient(patient)}
                    className={`border-b border-gray-100 cursor-pointer transition-colors ${idx % 2 === 0 ? "bg-white" : "bg-[#f0f7fc]"}`}
                  >
                    <td className="px-4 py-2.5 font-medium text-[#004b96] hover:underline">
                      {patient.firstName} {patient.lastName}
                    </td>
                    <td className="px-4 py-2.5 text-gray-700">{patient.age}</td>
                    <td className="px-4 py-2.5 text-gray-700">{patient.spouseName || patient.firstName}</td>
                    <td className="px-4 py-2.5 text-gray-700">{patient.children}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1">
                        <div className={`w-4 h-4 rounded border-2 ${patient.familyPlanning ? "bg-blue-200 border-blue-400" : "border-gray-300"}`} />
                        {patient.familyPlanning && (
                          <span className="text-xs text-gray-500">{patient.sex === "Female" ? "♀" : "♂"}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-gray-700">{patient.purok}</td>
                    <td className="px-4 py-2.5">
                      <button
                        onClick={(e) => { e.stopPropagation(); setEditingPatient(patient); }}
                        className="text-[#004b96] hover:text-[#003a75] hover:bg-[#e8f4fd] rounded p-1 transition-colors"
                      >
                        <Pencil size={14} />
                      </button>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-gray-200">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="flex items-center gap-1 bg-[rgba(0,122,255,0.5)] text-white px-3 py-1.5 rounded-md text-sm disabled:opacity-40 hover:bg-[rgba(0,122,255,0.7)] transition-colors"
          >
            <ChevronLeft size={14} />
            Previous
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`w-8 h-8 rounded-md text-sm font-semibold transition-colors ${
                currentPage === page
                  ? "bg-[#004b96] text-white"
                  : "bg-[rgba(0,122,255,0.3)] text-white hover:bg-[rgba(0,122,255,0.5)]"
              }`}
            >
              {page}
            </button>
          ))}
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages || totalPages === 0}
            className="flex items-center gap-1 bg-[rgba(0,122,255,0.5)] text-white px-3 py-1.5 rounded-md text-sm disabled:opacity-40 hover:bg-[rgba(0,122,255,0.7)] transition-colors"
          >
            Next
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Medical Profile Modal */}
      <AnimatePresence>
        {selectedPatient && (
          <PatientMedicalProfile
            patient={selectedPatient}
            onClose={() => setSelectedPatient(null)}
          />
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {editingPatient && (
          <PatientEditModal
            patient={editingPatient}
            onClose={() => setEditingPatient(null)}
            onSave={(updated) => { handleSavePatient(updated); setEditingPatient(null); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}