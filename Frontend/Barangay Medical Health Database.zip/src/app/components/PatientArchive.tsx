import { useState, useEffect } from "react";
import { Search, ChevronLeft, ChevronRight, Archive, Calendar, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import type { ArchiveEntry, Patient } from "./mockData";
import * as archiveService from "../../api/archive.service";
import * as patientsService from "../../api/patients.service";
import { PatientMedicalProfile } from "./PatientMedicalProfile";

const ITEMS_PER_PAGE = 9;

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: CURRENT_YEAR - 2010 + 1 }, (_, i) => String(2010 + i)).reverse();

function parseArchiveDate(dateStr: string): Date {
  return new Date(dateStr);
}

function parseDatetimeInput(val: string): Date | null {
  if (!val) return null;
  return new Date(val);
}

/** Find best-matching patient from loaded list by name */
function resolvePatient(entry: ArchiveEntry, allPatients: Patient[]): Patient {
  const match = allPatients.find(
    (p) =>
      p.lastName.toLowerCase() === entry.lastName.toLowerCase() &&
      p.firstName.toLowerCase() === entry.firstName.toLowerCase()
  );
  if (match) return match;
  // Fallback: build a minimal Patient shell so the modal still renders
  return {
    id: -entry.id,
    lastName: entry.lastName,
    firstName: entry.firstName,
    middleInitial: entry.middleInitial,
    age: 0,
    sex: "Male",
    birthday: "—",
    religion: "—",
    civilStatus: "—",
    educationalAttainment: "—",
    occupation: "—",
    contactNumber: "—",
    address: "—",
    barangay: "—",
    city: "—",
    purok: "—",
    program: "—",
    children: 0,
    bloodPressure: "—",
    weight: "—",
    height: "—",
    lastVisit: "—",
    coMorbidities: "—",
    allergies: "—",
    maintenanceMedication: "—",
    previousIllnesses: "—",
    familyHistoryConditions: [],
    familyHistoryOther: "—",
    familyHistoryMother: "N/A",
    familyPlanning: false,
    vitamins: false,
    bcgVaccine: "N/A",
    hepBVaccine: "N/A",
    vitaminK: "N/A",
  } as Patient;
}

export function PatientArchive() {
  const [archive, setArchive]         = useState<ArchiveEntry[]>([]);
  const [allPatients, setAllPatients] = useState<Patient[]>([]);
  const [loading, setLoading]         = useState(true);

  const [lastName, setLastName]   = useState("");
  const [firstName, setFirstName] = useState("");
  const [middleI, setMiddleI]     = useState("");
  const [afterDt, setAfterDt]     = useState("");
  const [beforeDt, setBeforeDt]   = useState("");
  const [filterMonth, setFilterMonth] = useState("");
  const [filterYear, setFilterYear]   = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const [selectedEntry, setSelectedEntry]     = useState<ArchiveEntry | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  // Load archive and patient list from services on mount
  useEffect(() => {
    Promise.all([archiveService.getArchive(), patientsService.getPatients()])
      .then(([arc, patients]) => {
        setArchive(arc);
        setAllPatients(patients);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const afterDate  = parseDatetimeInput(afterDt);
  const beforeDate = parseDatetimeInput(beforeDt);

  const filtered = archive.filter((entry) => {
    const lnMatch = entry.lastName.toLowerCase().includes(lastName.toLowerCase());
    const fnMatch = entry.firstName.toLowerCase().includes(firstName.toLowerCase());
    const miMatch = entry.middleInitial.toLowerCase().includes(middleI.toLowerCase());

    const startDate = parseArchiveDate(entry.startDatetime);
    const afterOk   = afterDate  ? startDate >= afterDate  : true;
    const beforeOk  = beforeDate ? startDate <= beforeDate : true;

    const monthOk = filterMonth
      ? startDate.toLocaleString("en-US", { month: "long" }) === filterMonth
      : true;
    const yearOk  = filterYear
      ? String(startDate.getFullYear()) === filterYear
      : true;

    return lnMatch && fnMatch && miMatch && afterOk && beforeOk && monthOk && yearOk;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const paginated  = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const resetPage = () => setCurrentPage(1);

  const hasFilters = lastName || firstName || middleI || afterDt || beforeDt || filterMonth || filterYear;

  const handleRowClick = (entry: ArchiveEntry) => {
    setSelectedEntry(entry);
    setSelectedPatient(resolvePatient(entry, allPatients));
  };

  const handleCloseProfile = () => {
    setSelectedEntry(null);
    setSelectedPatient(null);
  };

  const selectedTimeline = selectedEntry
    ? `${selectedEntry.startDatetime}  —  ${selectedEntry.endDatetime}`
    : undefined;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="flex flex-col h-full bg-[#004b96] rounded-2xl overflow-hidden shadow-lg"
        style={{ fontFamily: "'Poppins', sans-serif" }}
      >
        {/* Top Tab Bar */}
        <div className="flex items-center gap-2 px-4 pt-4">
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.3 }}
            className="bg-[#003a75] rounded-t-xl px-5 py-2 flex items-center gap-2"
          >
            <Archive size={14} className="text-white/80" />
            <span className="text-white font-bold text-sm">PATIENT ARCHIVE</span>
          </motion.div>
        </div>

        {/* Content */}
        <div className="flex-1 bg-[#1565c0] mx-2 mb-2 rounded-b-xl rounded-tr-xl p-4 flex flex-col gap-3">

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.15, duration: 0.3 }}
            className="flex flex-col gap-2"
          >
            {/* Row 1 — Name filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-2 bg-white rounded-full px-3 py-1.5 border border-gray-200 flex-1 min-w-[110px]">
                <Search size={13} className="text-gray-400 flex-shrink-0" />
                <input
                  type="text"
                  placeholder="Last Name"
                  value={lastName}
                  onChange={(e) => { setLastName(e.target.value); resetPage(); }}
                  className="flex-1 text-xs bg-transparent focus:outline-none text-gray-700 min-w-0"
                />
              </div>
              <div className="flex items-center gap-2 bg-white rounded-full px-3 py-1.5 border border-gray-200 flex-1 min-w-[110px]">
                <Search size={13} className="text-gray-400 flex-shrink-0" />
                <input
                  type="text"
                  placeholder="First Name"
                  value={firstName}
                  onChange={(e) => { setFirstName(e.target.value); resetPage(); }}
                  className="flex-1 text-xs bg-transparent focus:outline-none text-gray-700 min-w-0"
                />
              </div>
              <div className="flex items-center gap-2 bg-white rounded-full px-3 py-1.5 border border-gray-200 w-24 flex-shrink-0">
                <Search size={13} className="text-gray-400 flex-shrink-0" />
                <input
                  type="text"
                  placeholder="M.I."
                  value={middleI}
                  onChange={(e) => { setMiddleI(e.target.value); resetPage(); }}
                  className="w-full text-xs bg-transparent focus:outline-none text-gray-700"
                  maxLength={3}
                />
              </div>
            </div>

            {/* Row 2 — Timeframe + Month/Year dropdowns */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* After */}
              <div className="flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-gray-200 flex-1 min-w-[180px]">
                <Calendar size={13} className="text-gray-400 flex-shrink-0" />
                <span className="text-[10px] text-gray-400 font-semibold flex-shrink-0">AFTER</span>
                <input
                  type="datetime-local"
                  value={afterDt}
                  onChange={(e) => { setAfterDt(e.target.value); resetPage(); }}
                  className="flex-1 text-xs bg-transparent focus:outline-none text-gray-700 min-w-0"
                />
              </div>
              {/* Before */}
              <div className="flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-gray-200 flex-1 min-w-[180px]">
                <Calendar size={13} className="text-gray-400 flex-shrink-0" />
                <span className="text-[10px] text-gray-400 font-semibold flex-shrink-0">BEFORE</span>
                <input
                  type="datetime-local"
                  value={beforeDt}
                  onChange={(e) => { setBeforeDt(e.target.value); resetPage(); }}
                  className="flex-1 text-xs bg-transparent focus:outline-none text-gray-700 min-w-0"
                />
              </div>
            </div>

            {/* Row 3 — Month / Year dropdowns */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Month */}
              <div className="relative flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-gray-200 flex-1 min-w-[130px]">
                <span className="text-[10px] text-gray-400 font-semibold flex-shrink-0">MONTH</span>
                <select
                  value={filterMonth}
                  onChange={(e) => { setFilterMonth(e.target.value); resetPage(); }}
                  className="flex-1 text-xs bg-transparent focus:outline-none text-gray-700 appearance-none cursor-pointer min-w-0"
                >
                  <option value="">All Months</option>
                  {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
                </select>
                <ChevronDown size={12} className="text-gray-400 flex-shrink-0 pointer-events-none" />
              </div>
              {/* Year */}
              <div className="relative flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-gray-200 flex-1 min-w-[110px]">
                <span className="text-[10px] text-gray-400 font-semibold flex-shrink-0">YEAR</span>
                <select
                  value={filterYear}
                  onChange={(e) => { setFilterYear(e.target.value); resetPage(); }}
                  className="flex-1 text-xs bg-transparent focus:outline-none text-gray-700 appearance-none cursor-pointer min-w-0"
                >
                  <option value="">All Years</option>
                  {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
                </select>
                <ChevronDown size={12} className="text-gray-400 flex-shrink-0 pointer-events-none" />
              </div>
              {/* Clear button */}
              {hasFilters && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.85 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.85 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setLastName(""); setFirstName(""); setMiddleI("");
                    setAfterDt(""); setBeforeDt("");
                    setFilterMonth(""); setFilterYear("");
                    resetPage();
                  }}
                  className="bg-white/20 hover:bg-white/30 text-white text-xs px-4 py-1.5 rounded-full transition-colors flex-shrink-0"
                >
                  Clear All
                </motion.button>
              )}
            </div>
          </motion.div>

          {/* Table */}
          <div className="flex-1 overflow-hidden rounded-lg">
            <table className="w-full text-sm">
              <thead>
                <motion.tr
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="bg-[#004b96] text-white"
                >
                  <th className="px-4 py-2.5 text-left font-semibold">Patient Name</th>
                  <th className="px-4 py-2.5 text-left font-semibold">Timeline</th>
                </motion.tr>
              </thead>
              <tbody>
                <AnimatePresence mode="popLayout">
                  {loading ? (
                    <motion.tr key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                      <td colSpan={2} className="text-center py-8 text-white/70">
                        <svg className="animate-spin w-5 h-5 mx-auto text-white" viewBox="0 0 24 24" fill="none">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                        </svg>
                      </td>
                    </motion.tr>
                  ) : paginated.length === 0 ? (
                    <motion.tr
                      key="empty"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      <td colSpan={2} className="text-center py-8 text-white/70">No records found</td>
                    </motion.tr>
                  ) : (
                    paginated.map((entry, idx) => (
                      <motion.tr
                        key={entry.id}
                        initial={{ opacity: 0, x: -16 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 16 }}
                        transition={{ delay: idx * 0.04, duration: 0.22, ease: "easeOut" }}
                        whileHover={{ backgroundColor: "rgba(255,255,255,0.18)" }}
                        style={{ backgroundColor: idx % 2 === 0 ? "rgba(255,255,255,0.05)" : "rgba(255,255,255,0.1)", cursor: "pointer" }}
                        className="border-b border-white/10"
                        onClick={() => handleRowClick(entry)}
                      >
                        <td className="px-4 py-2.5 text-white font-medium">
                          {entry.lastName}, {entry.firstName} {entry.middleInitial}.
                        </td>
                        <td className="px-4 py-2.5">
                          <span className="inline-flex items-center gap-1.5 text-xs text-white/85">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#90caf9] flex-shrink-0" />
                            {entry.startDatetime}
                            <span className="text-white/40 mx-0.5">—</span>
                            <span className="w-1.5 h-1.5 rounded-full bg-[#a5d6a7] flex-shrink-0" />
                            {entry.endDatetime}
                          </span>
                        </td>
                      </motion.tr>
                    ))
                  )}
                </AnimatePresence>
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="flex items-center justify-end gap-2 pt-1"
          >
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="flex items-center gap-1 bg-[rgba(0,122,255,0.5)] text-white px-3 py-1.5 rounded-md text-sm disabled:opacity-40 hover:bg-[rgba(0,122,255,0.7)] transition-colors"
            >
              <ChevronLeft size={14} />
              Previous
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <motion.button
                key={page}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.92 }}
                onClick={() => setCurrentPage(page)}
                className={`w-8 h-8 rounded-md text-sm font-semibold transition-colors ${
                  currentPage === page
                    ? "bg-white text-[#004b96]"
                    : "bg-[rgba(255,255,255,0.2)] text-white hover:bg-[rgba(255,255,255,0.3)]"
                }`}
              >
                {page}
              </motion.button>
            ))}
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="flex items-center gap-1 bg-[rgba(0,122,255,0.5)] text-white px-3 py-1.5 rounded-md text-sm disabled:opacity-40 hover:bg-[rgba(0,122,255,0.7)] transition-colors"
            >
              Next
              <ChevronRight size={14} />
            </button>
          </motion.div>
        </div>
      </motion.div>

      {/* Patient Medical Profile Modal */}
      <AnimatePresence>
        {selectedPatient && (
          <PatientMedicalProfile
            patient={selectedPatient}
            onClose={handleCloseProfile}
            timeline={selectedTimeline}
          />
        )}
      </AnimatePresence>
    </>
  );
}