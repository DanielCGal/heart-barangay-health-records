// ─────────────────────────────────────────────────────────────────────────────
// Staff Service
//
// Endpoints expected from your backend:
//
//   GET    /staff                       → StaffMember[]
//                                         (list of all staff for dropdowns /
//                                          logbook username select)
//
//   GET    /staff/:id                   → StaffMember
//                                         (profile of a specific staff member)
//
// ── Note on the logged-in staff's own profile ─────────────────────────────────
//   To fetch the current staff member's own profile (for the Settings modal),
//   use getMe() in auth.service.ts (GET /auth/me) — NOT this service.
//   This service is for looking up OTHER staff members or populating lists.
// ─────────────────────────────────────────────────────────────────────────────

import {
  fakeDelay,
  // apiGet, // ← uncomment when connecting real backend
} from "./config";
import { mockStaff } from "../app/components/mockData";

// ── StaffMember type (extend as needed to match your backend schema) ──────────
export interface StaffMember {
  id       : string;
  fullName : string;
  username : string;   // displayed in logbook entries
  role     : string;
  email    : string;
}

// ─────────────────────────────────────────────────────────────────────────────
// getStaff
//
// Returns a list of all staff usernames / names.
// Used to populate username dropdowns in the Logbook Activity filter and
// other places that need to reference staff members by name.
// ─────────────────────────────────────────────────────────────────────────────
export async function getStaff(): Promise<string[]> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay();
  return [...mockStaff];
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // const members = await apiGet<StaffMember[]>("/staff");
  // return members.map((s) => s.username);   // or s.fullName — match your UI
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// getStaffById
//
// Fetches a single staff member's full profile by their ID.
// ─────────────────────────────────────────────────────────────────────────────
export async function getStaffById(id: string): Promise<StaffMember | null> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(120);
  // Mock returns null (no full StaffMember objects in mock data, only strings)
  console.warn(`getStaffById(${id}) — not available in mock mode.`);
  return null;
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiGet<StaffMember>(`/staff/${id}`);
  // ── END REAL ────────────────────────────────────────────────────────────────
}
