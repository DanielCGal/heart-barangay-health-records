// ─────────────────────────────────────────────────────────────────────────────
// Archive Service
//
// Endpoints expected from your backend:
//
//   GET    /archive                     → ArchiveEntry[]
//                                         (full list for Patient Archive table)
//
//   GET    /archive/patient/:patientId  → ArchiveEntry[]
//                                         (timeline of all snapshots for one
//                                          patient, newest-first)
//
//   POST   /archive                     body: ArchivePayload
//                                       → ArchiveEntry
//                                         (manually archive a patient record)
//
//   DELETE /archive/:id                 → 204 No Content
//                                         (restore / un-archive one snapshot)
//
// ── How the archive timeline works ───────────────────────────────────────────
//   Every time a staff member edits a patient, the OLD record is inserted into
//   the patient_archives table with:
//     • patientId     – links back to the patients table
//     • changedBy     – staff username who made the edit
//     • changedAt     – ISO timestamp of the change (used as the timeline label)
//   The Patient Archive screen fetches all archive rows, groups them by
//   patientId, and displays a timeline from the first snapshot to the latest.
//   Clicking any timeline entry calls getArchiveByPatientId() and then
//   displays that snapshot's full record.
// ─────────────────────────────────────────────────────────────────────────────

import {
  fakeDelay,
  // apiGet,    // ← uncomment when connecting real backend
  // apiPost,   // ← uncomment when connecting real backend
  // apiDelete, // ← uncomment when connecting real backend
} from "./config";
import { mockArchive } from "../app/components/mockData";
import type { ArchiveEntry } from "../app/components/mockData";

export type { ArchiveEntry };

// ── In-memory store ───────────────────────────────────────────────────────────
let _archive: ArchiveEntry[] = [...mockArchive];

// ─────────────────────────────────────────────────────────────────────────────
// getArchive
//
// Returns all archive entries. Used to populate the Patient Archive table.
// Each entry represents one saved snapshot of a patient at a point in time.
// ─────────────────────────────────────────────────────────────────────────────
export async function getArchive(): Promise<ArchiveEntry[]> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay();
  return [..._archive];
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiGet<ArchiveEntry[]>("/archive");
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// getArchiveByPatientId
//
// Returns all archived snapshots for a single patient, ordered newest-first.
// Used when a staff member clicks a patient row in the Patient Archive screen
// to view the full edit timeline for that patient.
//
// Frontend sends  : GET /archive/patient/:patientId  (Bearer token)
// Backend responds: ArchiveEntry[]  (all snapshots for that patient)
// ─────────────────────────────────────────────────────────────────────────────
export async function getArchiveByPatientId(
  patientId: number
): Promise<ArchiveEntry[]> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay();
  // Filter in-memory archive by patientId if the ArchiveEntry has that field;
  // otherwise return all (mock data may not have patientId per entry).
  const entries = _archive.filter(
    (a) => (a as ArchiveEntry & { patientId?: number }).patientId === patientId
  );
  // Fall back to returning all entries if no patientId field exists on mock data
  return entries.length > 0 ? [...entries] : [..._archive];
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiGet<ArchiveEntry[]>(`/archive/patient/${patientId}`);
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// archivePatient
//
// Manually archives a patient record snapshot.
// Always call addLogbookEntry({ action: "Archive", … }) alongside this.
//
// Note: When a patient is EDITED via updatePatient(), archiving the old
// snapshot is handled automatically by the backend. This function is for
// manual / explicit archiving (e.g. if a patient is permanently retired).
// ─────────────────────────────────────────────────────────────────────────────
export interface ArchivePayload {
  patientId     : number;
  lastName      : string;
  firstName     : string;
  middleInitial : string;
  startDatetime : string;   // ISO string or formatted date-time
  changedBy?    : string;   // staff username who triggered the archive
}

export async function archivePatient(
  payload: ArchivePayload
): Promise<ArchiveEntry> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(300);
  const now = new Date();
  const endDatetime = now.toLocaleString("en-US", {
    month: "long", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit", hour12: true,
  });
  const newId =
    _archive.length > 0 ? Math.max(..._archive.map((a) => a.id)) + 1 : 1;
  const entry: ArchiveEntry = {
    id            : newId,
    lastName      : payload.lastName,
    firstName     : payload.firstName,
    middleInitial : payload.middleInitial,
    startDatetime : payload.startDatetime,
    endDatetime,
  };
  _archive = [entry, ..._archive];
  return { ...entry };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiPost<ArchiveEntry>("/archive", payload);
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// restorePatient
//
// Removes a patient snapshot from the archive (un-archives / restores).
// Always call addLogbookEntry({ action: "Restore", … }) alongside this.
// ─────────────────────────────────────────────────────────────────────────────
export async function restorePatient(archiveId: number): Promise<void> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(250);
  _archive = _archive.filter((a) => a.id !== archiveId);
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // await apiDelete(`/archive/${archiveId}`);
  // ── END REAL ────────────────────────────────────────────────────────────────
}
