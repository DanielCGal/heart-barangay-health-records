// ─────────────────────────────────────────────────────────────────────────────
// Patients Service
//
// Endpoints expected from your backend:
//
//   GET    /patients                    → Patient[]
//                                         (full list shown in Patient Information table)
//
//   GET    /patients/:id                → Patient
//                                         (detail view when a row is clicked)
//
//   POST   /patients                    body: Omit<Patient,"id">
//                                       → Patient
//                                         (new patient or maternal registration)
//
//   PUT    /patients/:id                body: EditPatientPayload
//                                       → Patient
//                                         (edit existing patient; backend also
//                                          writes the old snapshot to archive)
//
//   DELETE /patients/:id                → 204 No Content
//
// ── Age-group logic ───────────────────────────────────────────────────────────
//   Frontend determines the age group from `patient.birthday` before rendering:
//     • "adult"  → 6 years old and above  → ITR 6+ tabs
//     • "child"  → 5 years old and below  → ITR ≤5 tabs
//   Use getPatientAgeGroup(patient) exported below.
//
// ── Edit flow (what the frontend sends on save) ───────────────────────────────
//   When a staff member saves edits, the frontend calls updatePatient() with:
//     • `id`          – patient's ID
//     • `newData`     – the full updated Patient object
//     • `oldData`     – snapshot of the patient BEFORE edits
//     • `changedBy`   – staff username performing the edit
//   The backend is expected to:
//     1. Overwrite the patient row with `newData`.
//     2. Insert the `oldData` snapshot into the patient_archives table
//        (with `changedAt` timestamp + `changedBy` staff name).
//   The frontend separately calls addLogbookEntry() after a successful save.
//
// ── Patient payload field notes ───────────────────────────────────────────────
//   • birthday        : "YYYY-MM-DD"        (e.g. "1993-03-15")
//   • lastVisit       : "YYYY-MM-DD"        (e.g. "2026-02-14")
//   • contactNumber   : digits only, 11 chars
//   • spouseContact   : digits only, 11 chars
//   • bloodPressure   : "X/Y mmHg"          (e.g. "120/80 mmHg")
//   • weight          : "X kg"              (e.g. "58 kg")
//   • height          : "X cm"              (e.g. "155 cm")
//   • coMorbidities   : comma-joined values (e.g. "Hypertension, Diabetes")
//                       or "None"
//   • cancer          : "None" | free-text
//   • allergies       : "None" | free-text
//   • tt1–tt5 (maternalRecord) : "Month YYYY" (e.g. "March 2021") or ""
// ─────────────────────────────────────────────────────────────────────────────

import {
  fakeDelay,
  // apiGet,    // ← uncomment when connecting real backend
  // apiPost,   // ← uncomment when connecting real backend
  // apiPut,    // ← uncomment when connecting real backend
  // apiDelete, // ← uncomment when connecting real backend
} from "./config";
import { mockPatients } from "../app/components/mockData";
import type { Patient } from "../app/components/mockData";

// Re-export the type so consumers can import from here
export type { Patient };

// ── In-memory store (acts as the database in mock mode) ───────────────────────
let _patients: Patient[] = [...mockPatients];

// ── Edit payload (includes old snapshot for automatic archiving) ──────────────
export interface EditPatientPayload {
  newData   : Patient;   // the updated patient record to save
  oldData   : Patient;   // snapshot before changes (backend archives this)
  changedBy : string;    // staff username who made the edit
  changedAt : string;    // ISO timestamp of the edit
}

// ─────────────────────────────────────────────────────────────────────────────
// getPatients
//
// Returns the full patient list for the Patient Information table.
// Supports server-side filtering if the backend accepts query params:
//   GET /patients?search=&ageGroup=&barangay=   (optional – backend-dependent)
// ─────────────────────────────────────────────────────────────────────────────
export async function getPatients(): Promise<Patient[]> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay();
  return [..._patients];
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiGet<Patient[]>("/patients");
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// getPatientById
//
// Fetches a single patient's full record when their row is clicked.
// Frontend then calls getPatientAgeGroup() to decide which tabs to show.
// ─────────────────────────────────────────────────────────────────────────────
export async function getPatientById(id: number): Promise<Patient> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay();
  const p = _patients.find((pt) => pt.id === id);
  if (!p) throw new Error(`Patient with id ${id} not found.`);
  return { ...p };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiGet<Patient>(`/patients/${id}`);
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// createPatient
//
// Registers a new patient (ITR 6+, ITR ≤5) or a new Maternal record for an
// existing female patient. Called from PatientRegistration on Save.
// After a successful create, call addLogbookEntry({ action: "Add Record", … }).
// ─────────────────────────────────────────────────────────────────────────────
export async function createPatient(
  data: Omit<Patient, "id">
): Promise<Patient> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(300);
  const newId = _patients.length > 0 ? Math.max(..._patients.map((p) => p.id)) + 1 : 1;
  const created: Patient = { ...data, id: newId } as Patient;
  _patients = [..._patients, created];
  return { ...created };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiPost<Patient>("/patients", data);
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// updatePatient
//
// Saves edited patient data. The payload includes both the new record AND the
// old snapshot so the backend can archive the previous state atomically.
//
// Backend expected behaviour:
//   1. UPDATE patients SET … WHERE id = payload.newData.id
//   2. INSERT INTO patient_archives (…, changedBy, changedAt) VALUES (oldData…)
//
// After a successful update, the frontend calls addLogbookEntry():
//   await addLogbookEntry({
//     staffUsername : payload.changedBy,
//     action        : "Edit Record",
//     patientName   : `${payload.newData.lastName}, ${payload.newData.firstName}`,
//     patientId     : payload.newData.id,
//   });
// ─────────────────────────────────────────────────────────────────────────────
export async function updatePatient(
  id: number,
  payload: EditPatientPayload
): Promise<Patient> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(300);
  _patients = _patients.map((p) => (p.id === id ? { ...payload.newData } : p));
  return { ...payload.newData };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiPut<Patient>(`/patients/${id}`, {
  //   newData   : payload.newData,
  //   oldData   : payload.oldData,
  //   changedBy : payload.changedBy,
  //   changedAt : payload.changedAt,
  // });
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// deletePatient
//
// Hard-deletes a patient record by ID.
// For soft-delete / archiving, use archivePatient() in archive.service.ts.
// ─────────────────────────────────────────────────────────────────────────────
export async function deletePatient(id: number): Promise<void> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(250);
  _patients = _patients.filter((p) => p.id !== id);
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // await apiDelete(`/patients/${id}`);
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// getPatientAgeGroup
//
// Pure frontend helper — NOT an API call.
// Derives "adult" or "child" from the patient's stored birthday so the UI
// knows which set of tabs to render (ITR 6+ vs ITR ≤5).
//
// Usage:
//   const group = getPatientAgeGroup(patient);
//   if (group === "adult") { /* show Medical History, Physical Exam 6+ … */ }
//   else                   { /* show Medical History, Physical Exam ≤5 … */ }
// ─────────────────────────────────────────────────────────────────────────────
export function getPatientAgeGroup(patient: Patient): "adult" | "child" {
  if (!patient.birthday) return "adult"; // default fallback
  const birth = new Date(patient.birthday);
  const now   = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const monthDiff = now.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
    age--;
  }
  return age >= 6 ? "adult" : "child";
}
