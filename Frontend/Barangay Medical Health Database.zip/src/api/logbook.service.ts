// ─────────────────────────────────────────────────────────────────────────────
// Logbook Service
//
// Endpoints expected from your backend:
//
//   GET    /logbook                     → LogbookEntry[]
//                                         (full list for Logbook Activity screen)
//
//   POST   /logbook                     body: NewLogbookEntry
//                                       → LogbookEntry
//                                         (add one activity entry)
//
//   PUT    /logbook/:id                 body: LogbookEntry
//                                       → LogbookEntry  (rarely needed)
//
// ── When to call addLogbookEntry() ───────────────────────────────────────────
//   Call this after EVERY staff action that changes patient data:
//
//   Action value       When to call
//   ─────────────────  ─────────────────────────────────────────────
//   "Add Record"       After createPatient() succeeds
//   "Edit Record"      After updatePatient() succeeds
//   "Delete Record"    After deletePatient() succeeds
//   "Archive"          After archivePatient() succeeds
//   "Restore"          After restorePatient() succeeds
//
//   The backend stores: staffUsername, action, patientName, patientId,
//   and a server-generated timestamp (ISO 8601).
// ─────────────────────────────────────────────────────────────────────────────

import {
  fakeDelay,
  // apiGet,  // ← uncomment when connecting real backend
  // apiPost, // ← uncomment when connecting real backend
  // apiPut,  // ← uncomment when connecting real backend
} from "./config";
import { mockLogbook } from "../app/components/mockData";
import type { LogbookEntry } from "../app/components/mockData";

export type { LogbookEntry };

// ── In-memory store ───────────────────────────────────────────────────────────
let _logbook: LogbookEntry[] = [...mockLogbook];

// ─────────────────────────────────────────────────────────────────────────────
// getLogbook
//
// Returns all logbook entries ordered newest-first for the Logbook Activity
// screen. The frontend can filter/search client-side from this list.
// ─────────────────────────────────────────────────────────────────────────────
export async function getLogbook(): Promise<LogbookEntry[]> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay();
  return [..._logbook];
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiGet<LogbookEntry[]>("/logbook");
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// addLogbookEntry
//
// Logs a staff activity. Call this after every patient create/edit/delete/
// archive/restore. The timestamp is generated server-side in the real API.
//
// Usage example (after editing a patient):
//   await addLogbookEntry({
//     staffUsername : "m.santos",
//     action        : "Edit Record",
//     patientName   : "del Rosario, Juniel",
//     patientId     : 1,
//   });
// ─────────────────────────────────────────────────────────────────────────────
export interface NewLogbookEntry {
  staffUsername : string;   // staff who performed the action
  action        : string;   // "Add Record" | "Edit Record" | "Delete Record" | "Archive" | "Restore"
  patientName   : string;   // full name snapshot — format: "LastName, FirstName"
  patientId?    : number;   // optional FK reference to patients.id
}

export async function addLogbookEntry(
  entry: NewLogbookEntry
): Promise<LogbookEntry> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(150);
  const now = new Date();
  const timestamp = now.toLocaleString("en-US", {
    month: "long", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit", hour12: true,
  });
  const newId =
    _logbook.length > 0 ? Math.max(..._logbook.map((e) => e.id)) + 1 : 1;
  const created: LogbookEntry = {
    id          : newId,
    username    : entry.staffUsername,
    action      : entry.action,
    patientName : entry.patientName,
    timestamp,
  };
  _logbook = [created, ..._logbook]; // newest first
  return { ...created };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiPost<LogbookEntry>("/logbook", {
  //   staffUsername : entry.staffUsername,
  //   action        : entry.action,
  //   patientName   : entry.patientName,
  //   patientId     : entry.patientId,
  //   // timestamp is generated server-side
  // });
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// updateLogbookEntry  (rarely used — mainly for admin corrections)
// ─────────────────────────────────────────────────────────────────────────────
export async function updateLogbookEntry(
  id: number,
  data: LogbookEntry
): Promise<LogbookEntry> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(250);
  _logbook = _logbook.map((e) => (e.id === id ? { ...data } : e));
  return { ...data };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // return apiPut<LogbookEntry>(`/logbook/${id}`, data);
  // ── END REAL ────────────────────────────────────────────────────────────────
}
