// ─────────────────────────────────────────────────────────────────────────────
// Auth Service
//
// Endpoints expected from your backend:
//
//   POST   /auth/login                  { identifier, password }
//                                       → { token: string; user: AuthUser }
//
//   POST   /auth/logout                 {}   → 204
//
//   GET    /auth/me                     (Bearer token)
//                                       → AuthUser
//
//   POST   /auth/forgot-password        { email: string }
//                                       → { message: string }
//                                         (backend sends OTP to that email)
//
//   POST   /auth/verify-reset-code      { email: string; code: string }
//                                       → { token: string; user: AuthUser }
//                                         (verifies OTP; returns new session)
//
//   POST   /auth/me/email/send-code     { newEmail: string }  (Bearer token)
//                                       → { message: string }
//                                         (backend sends OTP to the NEW email)
//
//   PATCH  /auth/me/email               { newEmail: string; code: string }
//                                       → AuthUser
//                                         (verifies OTP then persists new email)
//
//   PATCH  /auth/me/password            { currentPassword, newPassword }
//                                       → 204
// ─────────────────────────────────────────────────────────────────────────────

import {
  tokenStorage,
  userStorage,
  fakeDelay,
  // apiGet,    // ← uncomment when connecting real backend
  // apiPost,   // ← uncomment when connecting real backend
  // apiPatch,  // ← uncomment when connecting real backend
} from "./config";

// ── Shared type ───────────────────────────────────────────────────────────────
export interface AuthUser {
  id:       string;
  fullName: string;
  email:    string;
  role:     string;
}

// ── Mock seed (delete when backend is live) ───────────────────────────────────
const MOCK_PASSWORD = "password123";
const MOCK_USER: AuthUser = {
  id:       "staff-001",
  fullName: "Maria Santos",
  email:    "m.santos@healthcenter.gov.ph",
  role:     "Health Staff",
};

// ─────────────────────────────────────────────────────────────────────────────
// login
//
// Accepts either the staff's email address OR their staff ID as `identifier`.
// On success the backend returns a JWT token + the full AuthUser object.
// ─────────────────────────────────────────────────────────────────────────────
export async function login(
  identifier: string,
  password: string
): Promise<AuthUser> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(300);
  if (!identifier) throw new Error("Please enter your Staff Email or ID.");
  if (password !== MOCK_PASSWORD) throw new Error("Invalid credentials. Please try again.");
  tokenStorage.set("mock-jwt-" + Date.now());
  userStorage.set(MOCK_USER);
  return { ...MOCK_USER };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API (delete MOCK block above, then uncomment below) ────────────────
  // const res = await apiPost<{ token: string; user: AuthUser }>("/auth/login", {
  //   identifier,   // email or staff ID — backend handles both
  //   password,
  // });
  // tokenStorage.set(res.token);
  // userStorage.set(res.user);
  // return res.user;
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// logout
// ─────────────────────────────────────────────────────────────────────────────
export async function logout(): Promise<void> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  tokenStorage.clear();
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // await apiPost("/auth/logout", {});
  // tokenStorage.clear();
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// getMe
//
// Fetches the currently logged-in staff's profile from the backend.
// Called on app boot to hydrate the AuthContext if a token exists.
// ─────────────────────────────────────────────────────────────────────────────
export async function getMe(): Promise<AuthUser> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(120);
  return userStorage.get<AuthUser>() ?? { ...MOCK_USER };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // const user = await apiGet<AuthUser>("/auth/me");
  // userStorage.set(user);
  // return user;
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// sendForgotPasswordCode
//
// Step 1 of the "Forgot Password" flow.
// The frontend sends the staff's registered email address.
// The backend looks up the account and sends an OTP to that email.
//
// Frontend sends  : POST /auth/forgot-password  { email }
// Backend responds: 200 { message: "Code sent." }  or  404 if email not found
// ─────────────────────────────────────────────────────────────────────────────
export async function sendForgotPasswordCode(email: string): Promise<void> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(1100);
  // In mock mode we accept any valid-looking email without checking existence.
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    throw new Error("Please enter a valid email address.");
  // (No real email is sent; OTP is always "123456" in demo mode.)
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // await apiPost("/auth/forgot-password", { email });
  // Backend will:
  //   1. Look up the staff account by email.
  //   2. Generate a short-lived OTP (e.g. 6-digit, valid 10 min).
  //   3. Email the OTP to the staff's address.
  //   4. Respond 200 on success, 404 if email is not registered.
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// verifyForgotPasswordCode
//
// Step 2 of the "Forgot Password" flow.
// The frontend sends the email + the OTP the staff received.
// On success the backend returns a new JWT session so the staff is logged in.
//
// Frontend sends  : POST /auth/verify-reset-code  { email, code }
// Backend responds: 200 { token, user }  or  401 if code is wrong/expired
// ─────────────────────────────────────────────────────────────────────────────
export async function verifyForgotPasswordCode(
  email: string,
  code: string
): Promise<AuthUser> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(900);
  if (code.trim() !== "123456")
    throw new Error("Incorrect code. Please check your email and try again.");
  // Auto-issue a mock session
  tokenStorage.set("mock-jwt-reset-" + Date.now());
  userStorage.set(MOCK_USER);
  return { ...MOCK_USER };
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // const res = await apiPost<{ token: string; user: AuthUser }>(
  //   "/auth/verify-reset-code",
  //   { email, code }
  // );
  // tokenStorage.set(res.token);
  // userStorage.set(res.user);
  // return res.user;
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// sendEmailVerificationCode
//
// Step 1 of the "Change Email" flow in Settings.
// The frontend sends the NEW email the staff wants to switch to.
// The backend sends an OTP to that new email for ownership verification.
//
// Frontend sends  : POST /auth/me/email/send-code  { newEmail }  (Bearer token)
// Backend responds: 200 { message: "Code sent." }
// ─────────────────────────────────────────────────────────────────────────────
export async function sendEmailVerificationCode(newEmail: string): Promise<void> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(1100);
  if (!newEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail))
    throw new Error("Please enter a valid email address.");
  // (No real email is sent; OTP is always "123456" in demo mode.)
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // await apiPost("/auth/me/email/send-code", { newEmail });
  // Backend will:
  //   1. Validate the new email is not already taken.
  //   2. Generate an OTP and email it to `newEmail`.
  //   3. Respond 200 on success, 409 if email already in use.
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// updateEmail
//
// Step 2 of the "Change Email" flow.
// The frontend sends the new email + the OTP the staff received.
// Backend verifies the OTP then persists the new email in the staff record.
//
// Frontend sends  : PATCH /auth/me/email  { newEmail, code }  (Bearer token)
// Backend responds: 200 AuthUser (with updated email field)
// ─────────────────────────────────────────────────────────────────────────────
export async function updateEmail(
  newEmail: string,
  verificationCode: string
): Promise<AuthUser> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(400);
  if (verificationCode.trim() !== "123456")
    throw new Error("Incorrect verification code. Please check your email and try again.");
  const current = userStorage.get<AuthUser>() ?? MOCK_USER;
  const updated: AuthUser = { ...current, email: newEmail };
  userStorage.set(updated);
  return updated;
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // const updated = await apiPatch<AuthUser>("/auth/me/email", {
  //   newEmail,
  //   code: verificationCode,
  // });
  // userStorage.set(updated);
  // return updated;
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ─────────────────────────────────────────────────────────────────────────────
// updatePassword
//
// The frontend validates that `newPassword === confirmPassword` BEFORE calling
// this. Only the matching new password is sent to the backend.
//
// Frontend sends  : PATCH /auth/me/password  { currentPassword, newPassword }
// Backend responds: 204 No Content  or  401 if currentPassword is wrong
// ─────────────────────────────────────────────────────────────────────────────
export async function updatePassword(
  currentPassword: string,
  newPassword: string
): Promise<void> {
  // ── MOCK MODE ──────────────────────────────────────────────────────────────
  await fakeDelay(400);
  if (currentPassword !== MOCK_PASSWORD)
    throw new Error("Current password is incorrect.");
  if (newPassword.length < 6)
    throw new Error("Password must be at least 6 characters.");
  // In mock mode the new password is not persisted; backend handles hashing.
  // ── END MOCK ────────────────────────────────────────────────────────────────

  // ── REAL API ────────────────────────────────────────────────────────────────
  // await apiPatch("/auth/me/password", { currentPassword, newPassword });
  // ── END REAL ────────────────────────────────────────────────────────────────
}

// ── Helper: read persisted user (e.g. on page refresh) ───────────────────────
export function getStoredUser(): AuthUser {
  return userStorage.get<AuthUser>() ?? { ...MOCK_USER };
}
